<?php
session_start();

$con = mysql_connect("mysql6.000webhost.com","a6775547_a677554","trevor332");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("a6775547_a677554", $con);

            $id=$_POST['txtid'];
			$fname=$_POST['txtfname'];
			$lname=$_POST['txtlname'];
			$gender=$_POST['gender'];
			$age=$_POST['txtage'];
			$height=$_POST['txtheight'];
			$dssize=$_POST['txtdssize'];
			$waist=$_POST['txtwaist'];
			$hips=$_POST['txthips'];
			$eyescolor=$_POST['txteyescolor'];
			$haircolor=$_POST['txthaircolor'];
			$shoesize=$_POST['txtshoesize'];
			$bustchest=$_POST['txtbustchest'];
			$nationality=$_POST['txtnationality'];
			$address=$_POST['txtaddress'];
			$contactnum=$_POST['txtnum'];
			$mail=$_POST['txtmail'];
			$status=$_POST['txtstatus'];
			
 //send the email
		$to = $mail;
		$subject="notification From Pulcher Models Agency";
		$from = 'trevoroctober332@pulchermodels.comli.com';
		$body = "Testing add function ";	
		
		$headers = "From: $from \r\n";
		$headers .= "Reply-To: $$from \r\n";
		
		mail($to, $subject, $body,$headers);	
	
$query="INSERT INTO models(id,fname,lname,gender,age,height,dressuitsize,waist,hips,eyescolor,haircolor,shoesize,bustchest,nationality,address,contactnum,email,status) VALUES('$id','$fname','$lname','$gender','$age','$height','$dssize','$waist','$hips','$eyescolor','$haircolor','$shoesize','$bustchest','$nationality','$address','$contactnum','$mail','$status')";

$query2="DELETE FROM become WHERE id='$id'";

	mysql_query($query);
	mysql_query($query2);
	




header("location: Dashboard.php");
mysql_close($con);
?> 
