<?php
mysql_connect("mysql6.000webhost.com","a6775547_a677554"," trevor332") or die(mysql_error());
mysql_select_db("a6775547_a677554") or die(mysql_error());





	if (!isset($_FILES['image']['tmp_name'])) {
	echo "";
	}else{
	$name = $_FILES['image']['name'];
$extension = strtolower(substr($name, strpos($name, '.') + 1));
$size = $_FILES['image']['size'];
$max_size =2097152; //2097152 2mb

$type = $_FILES['image']['type'];


$tmp_name = $_FILES['image']['tmp_name'];
 if (!empty($name)){
  
   if (($extension=='jpg'||$extension=='jpeg')&&$type=='image/jpeg'&&$size<=$max_size) {
 
 $location="photos/" . $_FILES["image"]["name"];
 
 if(move_uploaded_file($tmp_name, $location)){
	
			$userid=$_POST['firstname'];
	
	
	$update=mysql_query("UPDATE models SET profile = '$location' WHERE id='$userid'");
			
			//echo 'uploaded';
			header("location: images.php");
			exit();
	
 }else{
	echo 'There was an error'; 
 }
 
 }else{
	echo 'File must be jpg/jpeg amd must be 2mb or less.'; 
 }
 }else{
	echo 'Please choose a file'; 
 }
}
?>

