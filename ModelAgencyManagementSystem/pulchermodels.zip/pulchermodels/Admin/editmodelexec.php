<?php
session_start();

$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("pulchermodels", $con);

$id = mysql_real_escape_string($_POST['txtid']);
$fname = stripslashes($_POST['txtfname']);
$lname = stripslashes($_POST['txtlname']);
$gender = stripslashes($_POST['gender']);	
$age = stripslashes($_POST['txtage']);
$height = stripslashes($_POST['txtheight']);
$dresssuit = stripslashes($_POST['txtdssize']);
$waist = stripslashes($_POST['txtwaist']);	
$hips = stripslashes($_POST['txthips']);
$eyescolor = stripslashes($_POST['txteyescolor']);
$haircolor = stripslashes($_POST['txthaircolor']);
$shoesize = stripslashes($_POST['txtshoesize']);   
$bustchest = stripslashes($_POST['txtbustchest']);
$nationalty = stripslashes($_POST['txtnationality']);
$address = stripslashes($_POST['txtaddress']);
$contact = stripslashes($_POST['txtcontactnum']);
$mail = stripslashes($_POST['txtmail']);

mysql_query("UPDATE models SET fname='".mysql_real_escape_string($fname)."', lname='".mysql_real_escape_string($lname)."', gender='".mysql_real_escape_string($gender)."', age='".mysql_real_escape_string($age)."', height='".mysql_real_escape_string($height)."', dressuitsize='".mysql_real_escape_string($dresssuit)."', waist='".mysql_real_escape_string($waist)."', hips='".mysql_real_escape_string($hips)."', eyescolor='".mysql_real_escape_string($eyescolor)."', haircolor='".mysql_real_escape_string($haircolor)."', shoesize='".mysql_real_escape_string($shoesize)."', bustchest='".mysql_real_escape_string($bustchest)."', nationality='".mysql_real_escape_string($nationalty)."', address='".mysql_real_escape_string($address)."', contactnum='".mysql_real_escape_string($contact)."', email='".mysql_real_escape_string($mail)."' WHERE id='$id'");	


//mysql_query("UPDATE models SET fname='$fname', lname='$lname', gender='$gender', age='$age', height='$height', dress/suitsize='$dress_suit', waist='$waist', hips='$hips', eyescolor='$eyescolor', haircolor='$haircolor', shoesize='$shoesize', bustchest='$bust_chest', nationality='$nationalty', address='$address', contactnum='$contact', email='$mail' WHERE id='$id'");

header("location: Dashboard.php");
mysql_close($con);
?> 
