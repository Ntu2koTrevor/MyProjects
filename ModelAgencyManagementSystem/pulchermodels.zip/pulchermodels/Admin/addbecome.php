<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add Model</title>
</head>

<body>
<?php
				  if (isset($_GET['id']))
	{
	
	echo '<form action="addbecomexec.php" method="POST">';
	
	
	echo '<br>';
	
			$con = mysql_connect("mysql6.000webhost.com", "a6775547_a677554", "trevor332");
			if (!$con)
  			{
  			die('Could not connect: ' . mysql_error());
  			}

			mysql_select_db("a6775547_a677554", $con);
		
			$id=$_GET['id'];
			$result = mysql_query("SELECT * FROM become WHERE id ='$id'");

			while($row = mysql_fetch_array($result))
  			{
			    echo'Add: '. $row['fname'];
			   echo '<br>';
			    echo '<input type="hidden" name="txtid" value="'. $row['id'] .'">';
			  
  			echo'<input type="hidden" name="txtfname" value="'. $row['fname'] .'">'; 
			  
			  echo'<input type="hidden" name="txtlname" value="'. $row['lname'] .'">';
			 
			  echo'<input type="hidden" name="gender" value="'. $row['gender'] .'">'; 
			  
			  echo'<input type="hidden" name="txtage" value="'. $row['age'] .'">';
			 
			   echo'<input type="hidden" name="txtheight" value="'. $row['height'] .'">'; 
			   
			  echo'<input type="hidden" name="txtdssize" value="'. $row['dresssuitsize'] .'">';
			 
			  echo'<input type="hidden" name="txtwaist" value="'. $row['waist'] .'">'; 
			 
			  echo'<input type="hidden" name="txthips" value="'. $row['hips'] .'">';
			
			   echo'<input type="hidden" name="txteyescolor" value="'. $row['eyescolor'] .'">'; 
			  
			  echo'<input type="hidden" name="txthaircolor" value="'. $row['haircolor'] .'">';
			
			  echo'<input type="hidden" name="txtshoesize" value="'. $row['shoesize'] .'">'; 
			
			  echo'<input type="hidden" name="txtbustchest" value="'. $row['bustchest'] .'">';
			 
			   echo'<input type="hidden" name="txtnationality" value="'. $row['nationality'] .'">'; 
			  
			  echo'<input type="hidden" name="txtaddress" value="'. $row['address'] .'">';
			  
			  echo'<input type="hidden" name="txtnum" value="'. $row['contactnum'] .'">'; 
			  
			  echo'<input type="hidden" name="txtmail" value="'. $row['email'] .'">';
			        
			  echo '<input type="hidden" name="txtstatus" value="'. $row['status'] .'">';
			
			  echo '<input name="" type="submit" value="Add" />';
  			}
	echo '</form>';
			}
			?>
</body>
</html>
