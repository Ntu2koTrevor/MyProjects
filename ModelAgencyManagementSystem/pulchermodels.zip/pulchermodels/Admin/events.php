<?php 
require "connect.php";
require_once('../auth.php');
?>
<html>
<head>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="febe/style.css" type="text/css" media="screen" charset="utf-8">

</head>
<body>
	<div id="container">
		<div id="adminbar-outer" class="radius-bottom">
			<div id="adminbar" class="radius-bottom">
				<a id="logo" href="dashboard.php"></a>
				<div id="details">
					
					<img width="36" height="36" alt="avatar" src="img/avatar.jpg">
					</a>
					<div class="tcenter">
					Hi
					<strong>Admin</strong>
					!
					<br>
					<a class="alightred" href="logoutadmin.php">Logout</a>
					</div>
				</div>
			</div>
		</div>
		<div id="panel-outer" class="radius" style="opacity: 1;">
			<div id="panel" class="radius">
				<ul class="radius-top clearfix" id="main-menu">
					<li>
						<a class="active" href="dashboard.php">
							<img alt="Dashboard" src="img/m-dashboard.png">
							<span>Dashboard</span>
						</a>
					</li>
					<li>
						<a href="become.php">
							<img alt="Users" src="img/become.jpg">
							<span>Become</span>
							<span class="submenu-arrow"></span>
						</a>
					</li>
					<li>
						<a href="women.php">
							<img alt="Articles" src="img/models.jpg">
							<span>Women</span>
							<span class="submenu-arrow"></span>
						</a>
					</li>
					<li>
						<a href="Men.php">
							<img alt="Newsletter" src="img/models.jpg">
							<span>Men</span>
						</a>
					</li>
					<li>
						<a href="images.php">
							<img alt="Statistics" src="img/m-gallery.png">
							<span>Image</span>
						</a>
					</li>
					
                     <li>
						<a href="#">
							<img alt="Custom" src="img/bookings.jpg">
							<span>Bookings</span>
						</a>
					</li>
                    <li>
						<a href="events.php">
							<img alt="Events" src="img/events.jpg">
							<span>Events</span>
						</a>
					</li>
                    <li>
						<a href="members.php">
							<img alt="Members" src="img/m-users.png">
							<span>Members</span>
						</a>
					</li>
					<div class="clearfix"></div>
				</ul>
				<div id="content" class="clearfix">
                <form action="dashboardsearch.php" method="post" name="">
					<label for="filter">Filter</label> <input type="text" name="search_name" placeholder="Search name" value="" id="filter" /> <input type="submit" name="submit" value="Search">
                    </form>
                    <a href="addevent.php">Add Event</a>
					<table cellpadding="1" cellspacing="1" id="resultTable">
						<thead>
							<tr>
								<th  style="border-left: 1px solid #C1DAD7">Id</th>
								<th> Date</th>
								<th> Description</th>
                                <th> Action 1</th>
								<th> Action 2</th>
							</tr>
						</thead>
						<tbody>
						<?php
						
							$result = mysql_query("SELECT * FROM events ORDER BY evdate ASC");
							while($row = mysql_fetch_array($result))
								{
									
									echo '<tr class="record">';
									
									echo '<td style="border-left: 1px solid #C1DAD7;">'.$row['id'].'</div></td>';
									echo '<td><div align="right">'.$row['evdate'].'</div></td>';
									echo '<td><div align="right">'.$row['description'].'</div></td>';
									echo '<td><div align="right">';
									echo '<a href=editevent.php?id=' . $row['id'] . '>' . 'Edit' . '</a>';
									echo '</div></td>';
									echo '<td><div align="right">';
									echo '<a href=delete_event.php?id=' . $row['id'] . '>' . 'Delete' . '</a>';
									echo '</div></td>';
									echo '</tr>';
								}
							?> 
						</tbody>
					</table>
				</div>
				<div id="footer" class="radius-bottom">
					2014-06 ©
					<a class="afooter-link" href="">Pulcher Models</a>
					by
					<a class="afooter-link" href="">ET_IT</a>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
	</div>
	
</script>
</body>
</html>
