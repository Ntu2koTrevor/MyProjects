<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Edit Event</title>
<script type="text/javascript">


	  function validateForm()
{
var a=document.forms["frmevent"]["txtdate"].value;
if (a==null || a=="")
  {
  alert("Date field is required ");
  return false;
  }
var b=document.forms["frmevent"]["txtdescription"].value;
if (b==null || b=="")
  {
  alert("Description field is required ");
  return false;
  }
 
}
	  </script>
</head>

<body>
<?php
				  if (isset($_GET['id']))
	{
	
	echo '<form action="editeventexce.php" method="post" name="frmevent" onsubmit="return validateForm()">';
	
	
	echo '<br>';
	echo '<input type="hidden" name="txtid" value="'. $_GET['id'] .'">';
			$con = mysql_connect("mysql6.000webhost.com", "a6775547_a677554", "trevor332");
			if (!$con)
			  {
			  die('Could not connect: ' . mysql_error());
			  }
			
			mysql_select_db("a6775547_a677554", $con);
		
			$id=$_GET['id'];
			$result = mysql_query("SELECT * FROM events WHERE id ='$id'");

			while($row = mysql_fetch_array($result))
  			{
			   echo '<br>';
  			echo'Date: '.'<input type="text" name="txtdate" maxlength="15" value="'. $row['evdate'] .'">'; 
			   echo '<br>';
			  echo'Description: '.'<input type="text" name="txtdescription" maxlength="250" value="'. $row['description'] .'">';

			   echo '<br>';
			  echo '<input name="" type="submit" value="Save" />';
  			}
	echo '</form>';
			}
			?>
</body>
</html>

