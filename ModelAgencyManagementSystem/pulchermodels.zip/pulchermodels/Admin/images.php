<?php 
require "connect.php";
require_once('../auth.php');
?>
<html>
<head>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="febe/style.css" type="text/css" media="screen" charset="utf-8">

</head>
<body>
	<div id="container">
		<div id="adminbar-outer" class="radius-bottom">
			<div id="adminbar" class="radius-bottom">
				<a id="logo" href="dashboard.php"></a>
				<div id="details">
					
					<img width="36" height="36" alt="avatar" src="img/avatar.jpg">
					</a>
					<div class="tcenter">
					Hi
					<strong>Admin</strong>
					!
					<br>
					<a class="alightred" href="logoutadmin.php">Logout</a>
					</div>
				</div>
			</div>
		</div>
		<div id="panel-outer" class="radius" style="opacity: 1;">
			<div id="panel" class="radius">
				<ul class="radius-top clearfix" id="main-menu">
					<li>
						<a class="active" href="dashboard.php">
							<img alt="Dashboard" src="img/m-dashboard.png">
							<span>Dashboard</span>
						</a>
					</li>
					<li>
						<a href="become.php">
							<img alt="Users" src="img/become.jpg">
							<span>Become</span>
							<span class="submenu-arrow"></span>
						</a>
					</li>
					<li>
						<a href="women.php">
							<img alt="Articles" src="img/models.jpg">
							<span>Women</span>
							<span class="submenu-arrow"></span>
						</a>
					</li>
					<li>
						<a href="Men.php">
							<img alt="Newsletter" src="img/models.jpg">
							<span>Men</span>
						</a>
					</li>
					<li>
						<a href="images.php">
							<img alt="Statistics" src="img/m-gallery.png">
							<span>Image</span>
						</a>
					</li>
					
                     <li>
						<a href="#">
							<img alt="Custom" src="img/bookings.jpg">
							<span>Bookings</span>
						</a>
					</li>
                    <li>
						<a href="events.php">
							<img alt="Events" src="img/events.jpg">
							<span>Events</span>
						</a>
					</li>
                    <li>
						<a href="members.php">
							<img alt="Custom" src="img/m-users.png">
							<span>Members</span>
						</a>
					</li>
					<div class="clearfix"></div>
				</ul>
				<div id="content" class="clearfix">
                <form action="imagesearch.php" method="post" name="">
					<label for="filter">Filter</label> <input type="text" name="search_name" placeholder="Search name"  value="" id="filter" /> <input type="submit" name="" value="Search">
                    </form>
                    <table cellpadding="1" cellspacing="1" id="resultTable">
						<thead>
							<tr>
								<th  style="border-left: 1px solid #C1DAD7">Id</th>
								<th> First Name</th>
								<th> Profile</th>
								<th> Image One</th>
                                <th> Image Two</th>
								<th> Image Three</th>
								<th> Image Four</th>
                                <th> Image Five</th>
							</tr>
						</thead>
						<tbody>
                         <?php
							
							$result = mysql_query("SELECT * FROM models ORDER BY fname ASC");
							while($row = mysql_fetch_array($result))
								{
									
									echo '<tr class="record">';
									
									echo '<td style="border-left: 1px solid #C1DAD7;">'.$row['id'].'</div></td>';
									echo '<td><div align="right">'.$row['fname'].'</div></td>';
									echo '<td><div align="center">';
									if($row['profile'] ==""){
                                    echo "<img width='100' height='100' src='../images/Default/default-medium.png' alt=Default Profile pic' title='Default image'>";
                                    echo '<br>';	
                                    echo '<a href=editprofile.php?id=' . $row['id'] . '>' . 'Edit' . '</a>';
                                    echo '&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
                                    echo '<a href=deleteprofile.php?id=' . $row['id'] . '>' . 'Delete' . '</a>';
                                    }else{
                                    echo "<img width='100' height='100' src='".$row['profile']."' alt=Preview'>";
                                    echo '<br>';	
                                    echo '<a href=editprofile.php?id=' . $row['id'] . '>' . 'Edit' . '</a>';
                                    echo '&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
                                    echo '<a href=deleteprofile.php?id=' . $row['id'] . '>' . 'Delete' . '</a>';		
                                    }	
									echo '<td><div align="center">';
									if($row['imageone'] ==""){
                                    echo "<img width='100' height='100' src='../images/Default/default-medium.png' Profile pic' title='Default image'>";
                                    echo '<br>';	
                                    echo '<a href=editimageone.php?id=' . $row['id'] . '>' . 'Edit' . '</a>';
                                    echo '&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
                                    echo '<a href=deleteimageone.php?id=' . $row['id'] . '>' . 'Delete' . '</a>';	
                                    }else{
                                    echo "<img width='100' height='100' src='".$row['imageone']."' alt=Preview'>";
                                    echo '<br>';	
                                    echo '<a href=editimageone.php?id=' . $row['id'] . '>' . 'Edit' . '</a>';
                                    echo '&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
                                    echo '<a href=deleteimageone.php?id=' . $row['id'] . '>' . 'Delete' . '</a>';		
                                    }
									echo '</div></td>';
									echo '<td><div align="center">';
									if($row['imagetwo'] ==""){
                                    echo "<img width='100' height='100' src='../images/Default/default-medium.png' Profile pic' title='Default image'>";	
                                    echo '<br>';	
                                    echo '<a href=editimagetwo.php?id=' . $row['id'] . '>' . 'Edit' . '</a>';
                                    echo '&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
                                    echo '<a href=deleteimagetwo.php?id=' . $row['id'] . '>' . 'Delete' . '</a>';
                                    }else{
                                    echo "<img width='100' height='100' src='".$row['imagetwo']."' alt=Preview'>";	
                                    echo '<br>';	
                                    echo '<a href=editimagetwo.php?id=' . $row['id'] . '>' . 'Edit' . '</a>';
                                    echo '&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
                                    echo '<a href=deleteimagetwo.php?id=' . $row['id'] . '>' . 'Delete' . '</a>';	
                                    }
									echo '</div></td>';
									echo '<td><div align="center">';
									if($row['imagethree'] ==""){
                                    echo "<img width='100' height='100' src='../images/Default/default-medium.png' Profile pic' title='Default image'>";
                                    echo '<br>';	
                                    echo '<a href=editimagethree.php?id=' . $row['id'] . '>' . 'Edit' . '</a>';
                                    echo '&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
                                    echo '<a href=deleteimagethree.php?id=' . $row['id'] . '>' . 'Delete' . '</a>';	
                                    }else{
                                    echo "<img width='100' height='100' src='".$row['imagethree']."' alt=Preview'>";	
                                    echo '<br>';	
                                    echo '<a href=editimagethree.php?id=' . $row['id'] . '>' . 'Edit' . '</a>';
                                    echo '&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
                                    echo '<a href=deleteimagethree.php?id=' . $row['id'] . '>' . 'Delete' . '</a>';	
                                    }	
									echo '</div></td>';
									echo '<td><div align="center">';
									if($row['imagefour'] ==""){
                                    echo "<img width='100' height='100' src='../images/Default/default-medium.png' Profile pic' title='Default image'>";
                                    echo '<br>';	
                                    echo '<a href=editimagefour.php?id=' . $row['id'] . '>' . 'Edit' . '</a>';
                                    echo '&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
                                    echo '<a href=deleteimagefour.php?id=' . $row['id'] . '>' . 'Delete' . '</a>';	
                                    }else{
                                    echo "<img width='100' height='100' src='".$row['imagefour']."' alt=Preview'>";	
                                    echo '<br>';	
                                    echo '<a href=editimagefour.php?id=' . $row['id'] . '>' . 'Edit' . '</a>';
                                    echo '&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
                                    echo '<a href=deleteimagefour.php?id=' . $row['id'] . '>' . 'Delete' . '</a>';	
                                    }	
									echo '</div></td>';
									echo '<td><div align="center">';
									if($row['imagefive'] ==""){
                                    echo "<img width='100' height='100' src='../images/Default/default-medium.png' Profile pic' title='Default image'>";
                                    echo '<br>';	
                                    echo '<a href=editimagefive.php?id=' . $row['id'] . '>' . 'Edit' . '</a>';
                                    echo '&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
                                    echo '<a href=deleteimagefive.php?id=' . $row['id'] . '>' . 'Delete' . '</a>';	
                                    }else{
                                    echo "<img width='100' height='100' src='".$row['imagefive']."' alt=Preview'>";
                                    echo '<br>';	
                                    echo '<a href=editimagefive.php?id=' . $row['id'] . '>' . 'Edit' . '</a>';
                                    echo '&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;';
                                    echo '<a href=deleteimagefive.php?id=' . $row['id'] . '>' . 'Delete' . '</a>';	
		
                                     }
									echo '</tr>';
								}
							?> 
						</tbody>
					</table>
				</div>
				<div id="footer" class="radius-bottom">
					2014-06 ©
					<a class="afooter-link" href="">Pulcher Models</a>
					by
					<a class="afooter-link" href="">ET_IT</a>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
	</div>
	
</script>
</body>
</html>

