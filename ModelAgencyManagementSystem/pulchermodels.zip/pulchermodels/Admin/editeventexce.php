<?php
session_start();

$con = mysql_connect("mysql6.000webhost.com", "a6775547_a677554", "trevor332");
			if (!$con)
			  {
			  die('Could not connect: ' . mysql_error());
			  }
			
			mysql_select_db("a6775547_a677554", $con);

$id = mysql_real_escape_string($_POST['txtid']);
$date = stripslashes($_POST['txtdate']);
$description = stripslashes($_POST['txtdescription']);


mysql_query("UPDATE events SET evdate='".mysql_real_escape_string($date)."', description='".mysql_real_escape_string($description)."' WHERE id='$id'");	


//mysql_query("UPDATE models SET fname='$fname', lname='$lname', gender='$gender', age='$age', height='$height', dress/suitsize='$dress_suit', waist='$waist', hips='$hips', eyescolor='$eyescolor', haircolor='$haircolor', shoesize='$shoesize', bustchest='$bust_chest', nationality='$nationalty', address='$address', contactnum='$contact', email='$mail' WHERE id='$id'");

header("location: Dashboard.php");
mysql_close($con);
?> 

