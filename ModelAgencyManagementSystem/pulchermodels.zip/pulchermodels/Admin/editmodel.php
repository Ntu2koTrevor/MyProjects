<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Edit Model</title>
<script type="text/javascript">

function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
	  function validateForm()
{
var a=document.forms["frmmodels"]["txtfname"].value;
if (a==null || a=="")
  {
  alert("Pls. provide your first name");
  return false;
  }
var b=document.forms["frmmodels"]["txtlname"].value;
if (b==null || b=="")
  {
  alert("Pls. provide your last name");
  return false;
  }
 var c=document.forms["frmmodels"]["gender"].value;
if (c==null || c=="")
  {
  alert("Pls. provide your gender");
  return false;
  }
var d=document.forms["frmmodels"]["txtage"].value;
if (d==null || d=="")
  {
  alert("Pls provide your age");
  return false;
  }
 var e=document.forms["frmmodels"]["txtheight"].value;
if (e==null || e=="")
  {
  alert("Pls. provide your height");
  return false;
  }
   var f=document.forms["frmmodels"]["txtdssize"].value;
if (f==null || f=="")
  {
  alert("Pls. provide your dress/suit size");
  return false;
  }
   var g=document.forms["frmmodels"]["txtwaist"].value;
if (g==null || g=="")
  {
  alert("Pls. provide your waist size");
  return false;
  }
   var h=document.forms["frmmodels"]["txthips"].value;
if (h==null || h=="")
  {
  alert("Pls. provide your hips size");
  return false;
  }
  var i=document.forms["frmmodels"]["txteyescolor"].value;
if (i==null || i=="")
  {
  alert("Pls. provide your eyes color");
  return false;
  }
  var j=document.forms["frmmodels"]["txthaircolor"].value;
if (j==null || j=="")
  {
  alert("Pls. provide your hair color");
  return false;
  }
  var k=document.forms["frmmodels"]["txtshoesize"].value;
if (k==null || k=="")
  {
  alert("Pls. provide your shoe size");
  return false;
  }
   var l=document.forms["frmmodels"]["txtbustchest"].value;
if (l==null || l=="")
  {
  alert("Pls. provide your bust/chest size");
  return false;
  }
   var m=document.forms["frmmodels"]["txtnationality"].value;
if (m==null || m=="")
  {
  alert("Pls. provide your nationality");
  return false;
  }
   var n=document.forms["frmmodels"]["txtaddress"].value;
if (n==null || n=="")
  {
  alert("Pls. provide your address");
  return false;
  }
  var o=document.forms["frmmodels"]["txtcontactnum"].value;
if (o==null || o=="")
  {
  alert("Pls. provide your contact number");
  return false;
  }
  var p=document.forms["frmmodels"]["txtmail"].value;
if (p==null || p=="")
  {
  alert("Pls. provide your email");
  return false;
  }
 

var atpos=p.indexOf("@");
var dotpos=p.lastIndexOf(".");
if (atpos<1 || dotpos<atpos+2 || dotpos+2>=p.length)
  {
  alert("Not a valid e-mail address");
  return false;
  }
}
	  </script>
</head>

<body>
<?php
				  if (isset($_GET['id']))
	{
	
	echo '<form action="editmodelexec.php" method="post" name="frmmodels" onsubmit="return validateForm()">';
	
	
	echo '<br>';
	echo '<input type="hidden" name="txtstatus" value="'. $_GET['id'] .'">';
			$con = mysql_connect("localhost", "root", "");
			if (!$con)
  			{
  			die('Could not connect: ' . mysql_error());
  			}

			mysql_select_db("pulchermodels", $con);
		
			$id=$_GET['id'];
			$result = mysql_query("SELECT * FROM models WHERE id ='$id'");

			while($row = mysql_fetch_array($result))
  			{
			 echo '<input type="hidden" name="txtid" value="'. $row['id'] .'">';
			   echo '<br>';
  			echo'First Name: '.'<input type="text" name="txtfname" maxlength="15" value="'. $row['fname'] .'">'; 
			   echo '<br>';
			  echo'Last Name: '.'<input type="text" name="txtlname" maxlength="15" value="'. $row['lname'] .'">';
			  echo '<br>';
			  echo'Gender: '.'<input type="text" name="gender" maxlength="6" value="'. $row['gender'] .'">'; 
			   echo '<br>';
			  echo'Age: '.'<input id="txtChar" onkeypress="return isNumberKey(event)" name="txtage" maxlength="2" value="'. $row['age'] .'">';
			   echo '<br>';
			   echo'Height: '.'<input id="txtChar" onkeypress="return isNumberKey(event)" name="txtheight" maxlength="3" value="'. $row['height'] .'">'; 
			   echo '<br>';
			  echo'Dress/Suit Size: '.'<input id="txtChar" onkeypress="return isNumberKey(event)" name="txtdssize" maxlength="2" value="'. $row['dressuitsize'] .'">';
			  echo '<br>';
			  echo'Waist: '.'<input id="txtChar" onkeypress="return isNumberKey(event)" name="txtwaist" maxlength="2" value="'. $row['waist'] .'">'; 
			   echo '<br>';
			  echo'Hips: '.'<input id="txtChar" onkeypress="return isNumberKey(event)" name="txthips" maxlength="2" value="'. $row['hips'] .'">';
			   echo '<br>';
			   echo'Eyes Color: '.'<input type="text" name="txteyescolor" maxlength="10" value="'. $row['eyescolor'] .'">'; 
			   echo '<br>';
			  echo'Hair Color: '.'<input type="text" name="txthaircolor" maxlength="10" value="'. $row['haircolor'] .'">';
			  echo '<br>';
			  echo'Shoe Size: '.'<input id="txtChar" onkeypress="return isNumberKey(event)" name="txtshoesize" maxlength="2" value="'. $row['shoesize'] .'">'; 
			   echo '<br>';
			  echo'Bust/Chest: '.'<input id="txtChar" onkeypress="return isNumberKey(event)" name="txtbustchest" maxlength="2" value="'. $row['bustchest'] .'">';
			   echo '<br>';
			   echo'Nationality: '.'<input type="text" name="txtnationality" maxlength="10" value="'. $row['nationality'] .'">'; 
			   echo '<br>';
			  echo'Address: '.'<input type="text" name="txtaddress" maxlength="30" value="'. $row['address'] .'">';
			  echo '<br>';
			  echo'Contact Number: '.'<input id="txtChar" onkeypress="return isNumberKey(event)" name="txtcontactnum" maxlength="10" value="'. $row['contactnum'] .'">'; 
			   echo '<br>';
			  echo'Email: '.'<input type="text" name="txtmail" value="'. $row['email'] .'">';
			   echo '<br>';
			  echo '<input name="" type="submit" value="Save" />';
  			}
	echo '</form>';
			}
			?>
</body>
</html>
