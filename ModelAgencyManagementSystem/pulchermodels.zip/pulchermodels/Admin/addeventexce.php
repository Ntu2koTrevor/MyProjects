<?php 
require "connect.php";

if (isset($_POST['btnsubmit'])){
if(isset($_POST['txtid'])&&
isset($_POST['txtdate'])&&
isset($_POST['description'])) 

$id = stripslashes($_POST['txtid']);
$date = stripslashes($_POST['txtdate']);
$Description = stripslashes($_POST['description']);

        	
$query="INSERT INTO events(id,evdate,description) VALUES('".mysql_real_escape_string($id)."','".mysql_real_escape_string($date)."','".mysql_real_escape_string($Description)."')";

	mysql_query($query);
	 //send the email
		/*$to = $email;
		$subject="notification From Pulcher Models Agency";
		$from = 'PulcherModels@gmail.com';
		$body = " ";	
		
		$headers = "From: $from \r\n";
		$headers .= "Reply-To: $$from \r\n";
		
		mail($to, $subject, $body,$headers);*/
	header("location: Dashboard.php");
}

?>


