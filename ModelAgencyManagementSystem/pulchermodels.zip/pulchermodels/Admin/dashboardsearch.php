<?php 
require "connect.php";
require_once('../auth.php');
?>
<html>
<head>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="febe/style.css" type="text/css" media="screen" charset="utf-8">

</head>
<body>
	<div id="container">
		<div id="adminbar-outer" class="radius-bottom">
			<div id="adminbar" class="radius-bottom">
				<a id="logo" href="dashboard.php"></a>
				<div id="details">
					
					<img width="36" height="36" alt="avatar" src="img/avatar.jpg">
					</a>
					<div class="tcenter">
					Hi
					<strong>Admin</strong>
					!
					<br>
					<a class="alightred" href="logoutadmin.php">Logout</a>
					</div>
				</div>
			</div>
		</div>
		<div id="panel-outer" class="radius" style="opacity: 1;">
			<div id="panel" class="radius">
				<ul class="radius-top clearfix" id="main-menu">
					<li>
						<a class="active" href="dashboard.php">
							<img alt="Dashboard" src="img/m-dashboard.png">
							<span>Dashboard</span>
						</a>
					</li>
					<li>
						<a href="become.php">
							<img alt="Users" src="img/become.jpg">
							<span>Become</span>
							<span class="submenu-arrow"></span>
						</a>
					</li>
					<li>
						<a href="women.php">
							<img alt="Articles" src="img/models.jpg">
							<span>Women</span>
							<span class="submenu-arrow"></span>
						</a>
					</li>
					<li>
						<a href="Men.php">
							<img alt="Newsletter" src="img/models.jpg">
							<span>Men</span>
						</a>
					</li>
					<li>
						<a href="images.php">
							<img alt="Statistics" src="img/m-gallery.png">
							<span>Image</span>
						</a>
					</li>
					
                     <li>
						<a href="#">
							<img alt="Custom" src="img/bookings.jpg">
							<span>Bookings</span>
						</a>
					</li>
                    <li>
						<a href="events.php">
							<img alt="Events" src="img/events.jpg">
							<span>Events</span>
						</a>
					</li>
                    <li>
						<a href="members.php">
							<img alt="Custom" src="img/m-users.png">
							<span>Members</span>
						</a>
					</li>
					<div class="clearfix"></div>
				</ul>
				<div id="content" class="clearfix">
                <form action="dashboardsearch.php" method="post" name="">
					<label for="filter">Filter</label> <input type="text" name="search_name" placeholder="Search name" value="" id="filter" /> <input type="submit" name="submit" value="Search">
                    </form>
					<table cellpadding="1" cellspacing="1" id="resultTable">
						<thead>
							<tr>
								<th  style="border-left: 1px solid #C1DAD7">Id</th>
								<th> First Name</th>
								<th> Last Name</th>
								<th> Gender</th>
                                <th> Age</th>
								<th> Nationality</th>
								<th> Address</th>
								<th> Contact Number</th>
								<th> Email</th>
							</tr>
						</thead>
						<tbody>
						<?php
						if (isset($_POST['search_name'])){
	
                        $search_name = mysql_real_escape_string($_POST['search_name']);	

                        if (!empty($search_name)){
	
	                    if (strlen($search_name)>=3) {
	
                        $query ="SELECT * FROM models WHERE fname LIKE '%".mysql_real_escape_string($search_name)."%'";
                        $query_run = mysql_query($query);
                        $query_num_rows = mysql_num_rows($query_run);
                        if ($query_num_rows>=1) {
	                    echo $query_num_rows.' Result found:<br>';
						
						while ($query_row = mysql_fetch_assoc($query_run)){
									
									echo '<tr class="record">';
									
									echo '<td style="border-left: 1px solid #C1DAD7;">'.$query_row['id'].'</div></td>';
									echo '<td><div align="right">'.$query_row['fname'].'</div></td>';
									echo '<td><div align="right">'.$query_row['lname'].'</div></td>';
									echo '<td><div align="right">'.$query_row['gender'].'</div></td>';
									echo '<td><div align="right">'.$query_row['age'].'</div></td>';
									echo '<td><div align="right">'.$query_row['nationality'].'</div></td>';
									echo '<td><div align="right">'.$query_row['address'].'</div></td>';
									echo '<td><div align="right">'.$query_row['contactnum'].'</div></td>';
									echo '<td><div align="right">'.$query_row['email'].'</div></td>';
									echo '</tr>';
						}
									
									}else{
                                       echo 'No result found';	
                                    }
	                              }else 'Your keyword must be 5 characters or more';
                                   }
								   }
								   
							?> 
						</tbody>
					</table>
				</div>
				<div id="footer" class="radius-bottom">
					2014-06 ©
					<a class="afooter-link" href="">Pulcher Models</a>
					by
					<a class="afooter-link" href="">ET_IT</a>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
	</div>
	
</script>
</body>
</html>