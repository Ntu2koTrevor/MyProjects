<?php
				  if (isset($_POST['yes']))
	{
			$con = mysql_connect("mysql6.000webhost.com", "a6775547_a677554", "trevor332");
			if (!$con)
			  {
			  die('Could not connect: ' . mysql_error());
			  }
			
			mysql_select_db("a6775547_a677554", $con);
			$messages_id = $_POST['id'];
			
			mysql_query("UPDATE models SET profile='' WHERE id='$messages_id'");
			header("location: Dashboard.php");
			exit();
			
			mysql_close($con);
			}
			 if (isset($_POST['no']))
	{
			
			header("location: Dashboard.php#4");
			exit();
		
			}
			?>
