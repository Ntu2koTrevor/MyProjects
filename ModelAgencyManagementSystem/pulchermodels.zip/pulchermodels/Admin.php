<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/admin.css" media="all"/>
<title>Admini Login</title>
</head>
<body>
<div id="prof1">
<form class="email" name="login" method="post" action="admin_login.php">
            <p align="center"><font color="black"><span style="font-size:12pt;"><b>Admin</b></span></font></p>
 <span style="font-size:10pt;">Username:</span>
<input type="text" name="user"><br/>
<span style="font-size:10pt;">Password:</span>
<input type="password" name="password"><br/>
<input class="send" type="submit" name="submit" value="Submit">
</form>
</div>
					

</body>
</html>
