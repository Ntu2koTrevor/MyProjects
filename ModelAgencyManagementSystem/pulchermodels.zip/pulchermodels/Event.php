<?php 
require_once'core.php';
require 'connect.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="generator" content="Adobe Dreamweaver Cs5">
    <meta name="description" content="Model agency ">
    <meta name="keywords" content="Modeling">
	<meta name="author" content="ET_IT">
    <meta name="robots" content="all">
   
<link rel="stylesheet" type="text/css" href="style.css" media="all"/>  
<script type="text/javascript">
function validateForm()
{
var a=document.forms["frmsearch"]["search_name"].value;
if (a==null || a=="")
  {
  alert("Your keyword must be 3 characters or more");
  return false;
  }
}
</script> 
<title>Events</title>
<style type="text/css">
	  
	  .Events{
	display: inline-block;
	width:1090px;
	margin-bottom: 30px;
	margin-top:20px;
}
	  </style>   

</head>
<body>
<div id="page">
<div id="header">
<div id="logo">
 <a href="index.html"><img src="images/Pulcher_Models2.jpg" width="300px" height="60px"></a>
</div><!-- /#logo-->
<form action="Search.php" method="post" class="searchbar" name="frmsearch" onsubmit="return validateForm()">
				<input type="text" placeholder="Search Model" name="search_name">
				<input type="submit" value="Go">
			</form>
            
 <div id="signup">
<a href="Registration/Sign_up.php">Sign Up</a> <span></span><span>|</span><a href="logout.php">Log-Out</a> <span></span>
</div> <!-- /#signup -->     
</div><!-- /#header -->

<div id="navcontainer">
                        <ul id="navlist">
                        
                                <!-- CSS Tabs -->
<li><a  href="userprofile.php">Profile</a></li>
<li><a href="News.php">News</a>

</li>
<li><a href="Fashion.php">Fashion</a></li>
<li><a href="Food.php">Food</a></li>
<li><a href="Event.php">Events</a></li>
<li><a href="Chatzone.php">Chat</a></li>
                        </ul>
                
</div> <!-- /#nav-->   


<?php
echo '<div class="Events">';
if (loggedin()) {

include 'show_calendar.php';	

}else{
	
include 'loginform.php';	
}
echo '</div>';//<!-- /#Events-->  
?>			
<div id="contents">


<div id="footer">
<a  href="index.html">Home</a><span>||</span>
<a  href="About.php">About Us</a><span>||</span>
<a href="Registration/Become.php">Become</a><span>||</span>
<a href="Contact.php">Contact Us</a>
 <p><a href="#"><img src="images/social/001.bmp" /></a>&nbsp; &nbsp;<a href="#"><img src="images/social/002.bmp" /></a>&nbsp; &nbsp;<a href="#"><img src="images/social/003.png" /></a></p> 
	<p>Copyright&copy;2014 PulcherModels.com. All rights reserved.| Design by (ET_IT)</p>
</div><!-- /#footer--> 
</div><!-- /#contents--> 
</div><!-- /#page-->
</body>
</html>




