<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Recover</title>
<style type="text/css">
<!--
#ed{
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
margin-bottom: 4px;
}
#button1{
text-align:center;
font-family:Arial, Helvetica, sans-serif;
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
background-color:#00CCFF;
height: 34px;
}
-->
</style>
<script type="text/javascript">
function validateForm()
{
 var p=document.forms["frmrecover"]["user"].value;
if (p==null || p=="")
  {
  alert("Pls. provide your email");
  return false;
  }
  var atpos=p.indexOf("@");
var dotpos=p.lastIndexOf(".");
if (atpos<1 || dotpos<atpos+2 || dotpos+2>=p.length)
  {
  alert("Not a valid e-mail address");
  return false;
  }
}
</script>
</head>

<body>
<form method="post" action="sendemail.php" name="frmrecover" onsubmit="return validateForm()">
Email:<br />
  <input type="text" name="user" id="ed" /><br />
<input name="submit" type="submit" value="Senmd my password to email" id="button1" />
</form>
</body>
</html>
