<?php 
require "connect.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="generator" content="Adobe Dreamweaver Cs5">
    <meta name="description" content="Model agency ">
    <meta name="keywords" content="Modeling">
	<meta name="author" content="ET_IT">
    <meta name="robots" content="all">
    
 <link rel="stylesheet" type="text/css" href="css/style_common.css" media="all"/>
 <link rel="stylesheet" type="text/css" href="css/style10.css" media="all"/>
 <link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>   
<link rel="stylesheet" type="text/css" href="style.css" media="all"/>   
<title>Model Profile</title>
<style type="text/css">
	  
	  .imagecontainer{
	display: inline-block;
	width:1090px;
	margin-bottom: 30px;
	margin-top:20px;
}
</style> 
 <script language="javascript">
  function function1(){
	  document.all.myMarquee.stop()
  }
  
  function function2(){
	  
	  document.all.myMarquee.start()
  }
  
 function validateForm()
{
var a=document.forms["frmsearch"]["search_name"].value;
if (a==null || a=="")
  {
  alert("Your keyword must be 3 characters or more");
  return false;
  }
} 
  
  </script>  
</head>
<body>
<div id="page">
<div id="header">
<div id="logo">
 <a href="index.html"><img src="images/Pulcher_Models2.jpg" width="300px" height="60px"></a>
</div><!-- /#logo-->
<form action="Search.php" method="post" class="searchbar" name="frmsearch" onsubmit="return validateForm()">
				<input type="text" placeholder="Search Model" name="search_name">
				<input type="submit" value="Go">
			</form>
            
 <div id="signup">
<a href="Registration/Sign_up.php">Sign Up</a> <span>|</span> <a href="userprofile.php">Log-in</a>
</div> <!-- /#signup -->     
</div><!-- /#header -->

<div id="navcontainer">
                        <ul id="navlist">
                        
                                <!-- CSS Tabs -->
<li><a  href="index.html">Home</a></li>
<li><a href="Women.php">Women</a></li>
<li><a href="Men.php">Men</a></li>
<li><a href="Registration/Become.php">Become</a></li>
<li><a href="Contact.php">Contact Us</a></li>
<li><a href="Entertainment.php">Entertainment</a></li>
                        </ul>
                
</div> <!-- /#nav-->   
<?php 
 if (isset($_GET['id']))
	{
$messages_id = $_GET['id'];
$result = mysql_query("SELECT * FROM models WHERE id ='$messages_id'");

echo "<div class='imagecontainer'>";
//whlie start
while($row = mysql_fetch_array($result))
  			{
	
echo "<div class='container'>";
echo "<marquee behavior='alternate' direction='left' scrollamount='3' id='myMarquee' onMouseOver='function1();' onMouseOut='function2();'>";
//profile img**************************************************************************************************************************************************
if($row['profile'] ==""){
echo "<img height='350' src='images/Default/shadow.jpg' alt=Default Profile pic' title='Default image'>";
 }else{
echo "<img height='350' src='Admin/".$row['profile']."' alt=Preview'>";                                	
}	
//img1*********************************************************************************************************************************************************
if($row['imageone'] ==""){
echo "<img height='350' src='images/Default/shadow.jpg' alt=Default Profile pic' Profile pic' title='Default image'>";
                                   
}else{
echo "<img height='350' src='Admin/".$row['imageone']."' alt=Preview'>";                                   	
}
//img2*********************************************************************************************************************************************************
if($row['imagetwo'] ==""){
echo "<img height='350' src='images/Default/shadow.jpg' alt=Default Profile pic' Profile pic' title='Default image'>";	
}else{
echo "<img height='350' src='Admin/".$row['imagetwo']."' alt=Preview'>";	                                   
}
//img3*********************************************************************************************************************************************************
if($row['imagethree'] ==""){
echo "<img height='350' src='images/Default/shadow.jpg' alt=Default Profile pic' Profile pic' title='Default image'>";
}else{
echo "<img height='350' src='Admin/".$row['imagethree']."' alt=Preview'>";	                                   
}	
//img4*********************************************************************************************************************************************************
if($row['imagefour'] ==""){
echo "<img height='350' src='images/Default/shadow.jpg' alt=Default Profile pic' Profile pic' title='Default image'>";
}else{
echo "<img height='350' src='Admin/".$row['imagefour']."' alt=Preview'>";	
}
//img5*********************************************************************************************************************************************************	
if($row['imagefive'] ==""){
echo "<img height='350' src='images/Default/shadow.jpg' alt=Default Profile pic' Profile pic' title='Default image'>";
}else{
echo "<img height='350' src='Admin/".$row['imagefive']."' alt=Preview'>";
}
echo "</marquee>";
echo "<br>";
echo "<br>";
echo "<font face='Georgia, Times New Roman, Times, serif' size='+2'>" .$row['fname']."</font>";
echo "<br>";
echo "<font face='Georgia, Times New Roman, Times, serif' color='#999999' size='2'>" . 'Height ' ."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#000000' size='-1'>" .$row['height'].'cm  '."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#999999' size='2'>" . 'Dress/Suitsize '."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#000000' size='-1'>" .$row['dressuitsize'].' SA  '."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#999999' size='2'>" . 'Waist  ' ."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#000000' size='-1'>" .$row['waist'].'cm  '."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#999999' size='2'>" . 'Hips ' ."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#000000' size='-1'>" .$row['hips'].'cm  '."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#999999' size='2'>" . 'Eyes Color ' ."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#000000' size='-1'>" .$row['eyescolor'].'  '."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#999999' size='2'>" . 'Haircolor ' ."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#000000' size='-1'>" .$row['haircolor'].'  '."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#999999' size='2'>" . 'Shoe Size ' ."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#000000' size='-1'>" .$row['shoesize'].' SA '."</font>";
echo "<br>";
echo "<font face='Georgia, Times New Roman, Times, serif' color='#999999' size='2'>" . 'Bust/Chest ' ."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#000000' size='-1'>" .$row['bustchest'].'  '."</font>";/*"<font face='Georgia, Times New Roman, Times, serif' color='#999999' size='2'>" . 'Status ' ."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#000000' size='-1'>" .$row['status']."</font>";*/

echo "</div>";//div container
			}//while end 
	}//get id
?> 
<div id="contents">


<div id="footer">
<a  href="index.html">Home</a><span>||</span>
<a  href="About.php">About Us</a><span>||</span>
<a href="Registration/Become.php">Become</a><span>||</span>
<a href="Contact.php">Contact Us</a>
 <p><a href="#"><img src="images/social/001.bmp" /></a>&nbsp; &nbsp;<a href="#"><img src="images/social/002.bmp" /></a>&nbsp; &nbsp;<a href="#"><img src="images/social/003.png" /></a></p> 
	<p>Copyright&copy;2014 PulcherModels.com. All rights reserved.| Design by (ET_IT)</p>
</div><!-- /#footer--> 
</div><!-- /#contents--> 
</div><!-- /#page-->
</body>
</html>

