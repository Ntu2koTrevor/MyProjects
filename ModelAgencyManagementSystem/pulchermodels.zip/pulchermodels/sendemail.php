<?php
$con = mysql_connect("mysql6.000webhost.com","a6775547_a677554","trevor332");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("a6775547_a677554", $con);

		$email = mysql_real_escape_string($_POST['user']);
		
		$result1 = mysql_query("SELECT * FROM members where email='$email'");
while($row = mysql_fetch_array($result1))
  {
  $password=$row['password'];
  $hash_pass = md5($password);
  }
$to=$email;

$subject="Your password here";

$header="from: your name <trevoroctober332@pulchermodels.comli.com>";

$messages= "Your password for login to our website \r\n";
$messages.="Your password is $hash_pass \r\n";
$messages.="more message... \r\n";

$sentmail = mail($email,$subject,$messages,$header);

		
		header('Location: index.html');
?>