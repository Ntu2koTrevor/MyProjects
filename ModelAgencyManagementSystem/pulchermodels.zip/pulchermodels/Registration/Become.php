<?php 
require "connect.php";

function createRandomPassword() {
					$chars = "abcdefghijkmnopqrstuvwxyz023456789";
					srand((double)microtime()*1000000);
					$i = 0;
					$pass = '' ;
					while ($i <= 7) {
						$num = rand() % 33;
						$tmp = substr($chars, $num, 1);
						$pass = $pass . $tmp;
						$i++;
					}
					return $pass;
				}
				$confirmation = createRandomPassword();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="generator" content="Adobe Dreamweaver Cs5">
    <meta name="description" content="Model agency ">
    <meta name="keywords" content="Modeling">
	<meta name="author" content="ET_IT">
    <meta name="robots" content="all">
    
 <link rel="stylesheet" type="text/css" href="../css/style_common.css" media="all"/>
 <link rel="stylesheet" type="text/css" href="../css/style10.css" media="all"/>
 <link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>   
<link rel="stylesheet" type="text/css" href="../style.css" media="all"/>  
<link rel="stylesheet" type="text/css" href="../css/Become.css" media="all"/>   
<title>Become</title>
<script type="text/javascript">

function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
function validateForm2()
{
var a=document.forms["frmsearch"]["search_name"].value;
if (a==null || a=="")
  {
  alert("Your keyword must be 3 characters or more");
  return false;
  }
}
function validateForm()
{
var a=document.forms["frmbecome"]["txtfname"].value;
if (a==null || a=="")
  {
  alert("Pls. provide your first name");
  return false;
  }
var b=document.forms["frmbecome"]["txtlname"].value;
if (b==null || b=="")
  {
  alert("Pls. provide your last name");
  return false;
  }
 var c=document.forms["frmbecome"]["gender"].value;
if (c==null || c=="")
  {
  alert("Pls. provide your gender");
  return false;
  }
var d=document.forms["frmbecome"]["txtage"].value;
if (d==null || d=="")
  {
  alert("Pls provide your age");
  return false;
  }
 var e=document.forms["frmbecome"]["txtheight"].value;
if (e==null || e=="")
  {
  alert("Pls. provide your height");
  return false;
  }
   var f=document.forms["frmbecome"]["txtdssize"].value;
if (f==null || f=="")
  {
  alert("Pls. provide your dress/suit size");
  return false;
  }
   var g=document.forms["frmbecome"]["txtwaist"].value;
if (g==null || g=="")
  {
  alert("Pls. provide your waist size");
  return false;
  }
   var h=document.forms["frmbecome"]["txthips"].value;
if (h==null || h=="")
  {
  alert("Pls. provide your hips size");
  return false;
  }
  var i=document.forms["frmbecome"]["txteyescolor"].value;
if (i==null || i=="")
  {
  alert("Pls. provide your eyes color");
  return false;
  }
  var j=document.forms["frmbecome"]["txthaircolor"].value;
if (j==null || j=="")
  {
  alert("Pls. provide your hair color");
  return false;
  }
  var k=document.forms["frmbecome"]["txtshoesize"].value;
if (k==null || k=="")
  {
  alert("Pls. provide your shoe size");
  return false;
  }
   var l=document.forms["frmbecome"]["txtbustchest"].value;
if (l==null || l=="")
  {
  alert("Pls. provide your bust/chest size");
  return false;
  }
   var m=document.forms["frmbecome"]["txtnationality"].value;
if (m==null || m=="")
  {
  alert("Pls. provide your nationality");
  return false;
  }
   var n=document.forms["frmbecome"]["txtaddress"].value;
if (n==null || n=="")
  {
  alert("Pls. provide your address");
  return false;
  }
  var o=document.forms["frmbecome"]["txtnum"].value;
if (o==null || o=="")
  {
  alert("Pls. provide your contact number");
  return false;
  }
  var p=document.forms["frmbecome"]["txtmail"].value;
if (p==null || p=="")
  {
  alert("Pls. provide your email");
  return false;
  }
  var q=document.forms["frmbecome"]["txtfull"].value;
if (q==null || q=="")
  {
  alert("Pls. browse an image");
  return false;
  }
var atpos=p.indexOf("@");
var dotpos=p.lastIndexOf(".");
if (atpos<1 || dotpos<atpos+2 || dotpos+2>=p.length)
  {
  alert("Not a valid e-mail address");
  return false;
  }
}
</script>
</head>
<body>
<div id="page">
<div id="header">
<div id="logo">
 <a href="../index.html"><img src="../images/Pulcher_Models2.jpg" width="300px" height="60px"></a>
</div><!-- /#logo-->
<form action="../Search.php" method="post" class="searchbar" name="frmsearch" onsubmit="return validateForm1()">
				<input type="text" placeholder="Search Model" name="search_name">
				<input type="submit" value="Go">
			</form>
            
 <div id="signup">
<a href="Sign_up.php">Sign Up</a> <span>|</span> <a href="../userprofile.php">Log-in</a>
</div> <!-- /#signup -->     
</div><!-- /#header -->

<div id="navcontainer">
                        <ul id="navlist">
                        
                                <!-- CSS Tabs -->
<li><a  href="../index.html">Home</a></li>
<li><a href="../Women.php">Women</a></li>
<li><a href="../Men.php">Men</a></li>
<li><a href="../Registration/Become.php">Become</a></li>
<li><a href="../Contact.php">Contact Us</a></li>
<li><a href="../Entertainment.php">Entertainment</a></li>
                        </ul>
                
</div> <!-- /#nav-->   
<div class="become">
<div class="container" style="float: left; width:450px;">
		
			<span class="top-label">
				<span class="label-txt">How to submit</span>
			</span>
			
			<div class="content-area" style="border-radius:15px;">
            <p style="width:400px">Looking for Females 170cm to 185cm / males 180cm to 190cm 
                                    between 15 years and 35 years old.


</p>
		
				<p style="width:400px">Please only submit NATURAL photographs, no professional 
                                       studio photos are required, as we wish to see you in your 
                                       most natural state. Digitally enhanced photographs are NOT
                                       to be submitted. Underwear shots are not required at this 
                                       stage of the application. Please do not wear make-up, as we 
                                       must see your true skin complexion. Hair must be naturally 
                                       styled, with no visible hair products and it must not obstruct 
                                       Your face and bone structure in the head-shot. 

</p>
                  <p style="width:400px">The mid-length and full-length shots should be taken whilst
                                         fully clothed, please refrain from wearing excessively loose 
                                         clothing in these pictures. Stand up straight in the shots and
                                         try to look as natural as possible. NB we are a Durban based
                                         model agency only submit your pictures if you intend or are 
                                         able to travel and stay in Durban to work.
</p>
	
					
				

			</div>
		</div>

<div class="container" style="float: left; width: 600px; padding-bottom: 15px; margin-left: 12px;">
			<span class="top-label">
				<span class="label-txt">Personal Details</span>
			</span>
			<div class="content-area" style="border-radius:15px; padding-bottom: 25px;">
				<div>
                <table>
                <form action="becomexec.php" method="POST" enctype="multipart/form-data" name="frmbecome" onsubmit="return validateForm()" >
                    <input type="hidden" name="txtid" value="<?php echo $confirmation ?>" />
					<tr><td>Firstname:</td><td><input type="text" maxlength="15" name="txtfname" placeholder="First Name" id="boxy" /></td>
					
					<td>Lastname:</td><td><input type="text" maxlength="15" name="txtlname" placeholder="Last Name" id="boxy" /></td></tr>
					
					<tr><td>Gender:</td><td><select name="gender" id="boxy"><option value="Male">Male</option><option value="Female">Female</option></select></td>
					
					<td>Age:</td><td><input id="txtChar" onkeypress="return isNumberKey(event)" maxlength="2" name="txtage" placeholder="Age" /></td></tr>
					
					<tr><td>Height:</td><td><input id="txtChar" onkeypress="return isNumberKey(event)" maxlength="3" name="txtheight" placeholder="Height.cm"/></td>
					
					<td>Dress/Suit Size:</td><td><input id="txtChar" onkeypress="return isNumberKey(event)" maxlength="2" name="txtdssize" placeholder="Dress/Suit Size.SA" /><br></td></tr>
					
					<tr><td>Waist:</td><td><input id="txtChar" onkeypress="return isNumberKey(event)" maxlength="2" name="txtwaist" placeholder="Waist.cm" /></td>
					<td>Hips:</td><td><input id="txtChar" onkeypress="return isNumberKey(event)" maxlength="2" name="txthips" placeholder="Hips.cm" /></td></tr>
                    <tr><td>Eyes Color:</td><td><input type="text" maxlength="10" name="txteyescolor" placeholder="Eyes Color" id="boxy" /></td>
					
					<td>Hair Color:</td><td><input type="text" maxlength="10" name="txthaircolor" placeholder="Hair Color"id="boxy" /></td></tr>
					
					<tr><td>Shoe Size:</td><td><input id="txtChar" onkeypress="return isNumberKey(event)" maxlength="2" name="txtshoesize" placeholder="Shoe Size.SA" /></td>
					
					<td>Bust/Chest:</td><td><input id="txtChar" onkeypress="return isNumberKey(event)" maxlength="2"name="txtbustchest" placeholder="Bust/Chest" /><br></td></tr>
					
					<tr><td>Nationality:</td><td><input type="text" maxlength="20" name="txtnationality" placeholder="Nationality" id="boxy" /></td>
					
					<td>Address:</td><td><input type="text" maxlength="30"name="txtaddress" placeholder="Address" id="boxy" /></td></tr>
					
					<tr><td>Contact Number:</td><td><input id="txtChar" onkeypress="return isNumberKey(event)" maxlength="10" name="txtnum" placeholder="Contact Number"  /></td>
					<td>Email:</td><td><input type="text" name="txtmail" placeholder="Email" id="boxy" /></td></tr>
                    <tr><td>Full Length Image:</td><td><input type="file" name="txtfull" id="boxy" /></td>
				<td></td><td>
		            <input type="hidden" name="txtstatus" value="Available" />
					<input type="submit" name="" value="Submit" id="boxy"  style="width: 147px; margin-top: 18px;"></td></tr>
                    </form>
                    </table>
                     <p style="width:400px">NB: Ensure that the images you send via the online
                                           Form are not lager than 2MB in size each.
                </p>
				</div>
			</div>
		</div>

<div id="contents">
<div id="footer">
<a  href="../index.html">Home</a><span>||</span>
<a  href="../About.php">About Us</a><span>||</span>
<a href="Become.php">Become</a><span>||</span>
<a href="../Contact.php">Contact Us</a>
 <p><a href="#"><img src="../images/social/001.bmp" /></a>&nbsp; &nbsp;<a href="#"><img src="../images/social/002.bmp" /></a>&nbsp; &nbsp;<a href="#"><img src="../images/social/003.png" /></a></p> 
	<p>Copyright&copy;2014 PulcherModels.com. All rights reserved.| Design by (ET_IT)</p>
</div><!-- /#footer--> 
</div><!-- /#contents--> 
</div><!-- /#page-->
</body>
</html>
