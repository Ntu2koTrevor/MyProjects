<?php
mysql_connect("mysql6.000webhost.com","a6775547_a677554","trevor332") or die(mysql_error());
mysql_select_db("a6775547_a677554") or die(mysql_error());





	if (!isset($_FILES['txtfull']['tmp_name'])) {
	echo "";
	}else{
	$name = $_FILES['txtfull']['name'];
$extension = strtolower(substr($name, strpos($name, '.') + 1));
$size = $_FILES['txtfull']['size'];
$max_size =2097152; //2097152 2mb

$type = $_FILES['txtfull']['type'];


$tmp_name = $_FILES['txtfull']['tmp_name'];
 if (!empty($name)){
  
   if (($extension=='jpg'||$extension=='jpeg')&&$type=='image/jpeg'&&$size<=$max_size) {
 
 $location="photos/" . $_FILES["txtfull"]["name"];
 
 if(move_uploaded_file($tmp_name, $location)){
	
			$id=stripslashes($_POST['txtid']);
			$fname=stripslashes($_POST['txtfname']);
			$lname=stripslashes($_POST['txtlname']);
			$gender=stripslashes($_POST['gender']);
			$age=stripslashes($_POST['txtage']);
			$height=stripslashes($_POST['txtheight']);
			$dssize=stripslashes($_POST['txtdssize']);
			$waist=stripslashes($_POST['txtwaist']);
			$hips=stripslashes($_POST['txthips']);
			$eyescolor=stripslashes($_POST['txteyescolor']);
			$haircolor=stripslashes($_POST['txthaircolor']);
			$shoesize=stripslashes($_POST['txtshoesize']);
			$bustchest=stripslashes($_POST['txtbustchest']);
			$nationality=stripslashes($_POST['txtnationality']);
			$address=stripslashes($_POST['txtaddress']);
			$contactnum=stripslashes($_POST['txtnum']);
			$mail=stripslashes($_POST['txtmail']);
			$status=stripslashes($_POST['txtstatus']);
			
	
	$update=mysql_query("INSERT INTO become (id, fname, lname, gender, age, height, dresssuitsize, waist, hips, eyescolor, haircolor, shoesize, bustchest, nationality, address, contactnum, email, fulllength, status)
VALUES
('".mysql_real_escape_string($id)."','".mysql_real_escape_string($fname)."','".mysql_real_escape_string($lname)."','".mysql_real_escape_string($gender)."','".mysql_real_escape_string($age)."','".mysql_real_escape_string($height)."','".mysql_real_escape_string($dssize)."','".mysql_real_escape_string($waist)."','".mysql_real_escape_string($hips)."','".mysql_real_escape_string($eyescolor)."','".mysql_real_escape_string($haircolor)."','".mysql_real_escape_string($shoesize)."','".mysql_real_escape_string($bustchest)."','".($nationality)."','".mysql_real_escape_string($address)."','".mysql_real_escape_string($contactnum)."','".mysql_real_escape_string($mail)."','".mysql_real_escape_string($location)."','".mysql_real_escape_string($status)."')");
	
	 //send the email
		$to = $mail;
		$subject="notification From Pulcher Models Agency";
		$from = 'trevoroctober332@pulchermodels.comli.com';
		$body = "Thanks for applying. Please note, if you don't hear from us within 24 hours please consider your application unsuccessful.";	
		
		$headers = "From: $from \r\n";
		$headers .= "Reply-To: $$from \r\n";
		
		mail($to, $subject, $body,$headers);		
		
			header("location: ../index.html");
			exit();
	
 }else{
	echo 'There was an error'; 
 }
 
 }else{
	echo 'File must be jpg/jpeg amd must be 2mb or less.'; 
 }
 }else{
	echo 'Please choose a file'; 
 }
}
?>

