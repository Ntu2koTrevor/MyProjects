<?php 
require "connect.php";

if (isset($_POST['btnsubmit'])){
if(isset($_POST['txtid'])&&
isset($_POST['txtfname'])&&
isset($_POST['txtlname'])&&
isset($_POST['txtaddress'])&&
isset($_POST['txtcity'])&&
isset($_POST['txtcountry'])&&
isset($_POST['txtnum'])&&
isset($_POST['txtmail'])&&
isset($_POST['txtpass'])) 

$id = stripslashes($_POST['txtid']);
$fname = stripslashes($_POST['txtfname']);
$lname = stripslashes($_POST['txtlname']);
$address = stripslashes($_POST['txtaddress']);
$city = stripslashes($_POST['txtcity']);
$country = stripslashes($_POST['txtcountry']);
$contactnum = stripslashes($_POST['txtnum']);
$email = stripslashes($_POST['txtmail']);
$password = stripslashes($_POST['txtpass']);
$hash_pass = md5($password);

 if (empty($fname)&& empty($lname)&& empty($address)&& empty($city)&& empty($country)&& empty($contactnum)&& empty($email)&& empty($password)){
	 echo 'All fields are required ';
 }else{
 if (strlen($fname)>15||strlen($lname)>15||strlen($address)>30||strlen($city)>15||strlen($country)>20||strlen($contactnum)>10||strlen($email)>50||strlen($password)>20){
	echo 'Place adhear to the maxlength of fields '; 	 
 }
 }
 if (strlen($contactnum)<10){
	 echo 'Contact number field must contain 10 digits ';
 }
 else{
$querycheck = "SELECT email FROM members WHERE email ='$email'";
$query_run = mysql_query($querycheck);
if (mysql_num_rows($query_run)==1) {
	echo 'The Email '.$email.' already exists. ';
	
}else{
	
$query="INSERT INTO members(id,fname,lname,address,city,country,contactnum,email,password) VALUES('".mysql_real_escape_string($id)."','".mysql_real_escape_string($fname)."','".mysql_real_escape_string($lname)."','".mysql_real_escape_string($address)."','".mysql_real_escape_string($city)."','".mysql_real_escape_string($country)."','".mysql_real_escape_string($contactnum)."','".mysql_real_escape_string($email)."','".mysql_real_escape_string($hash_pass)."')";

	mysql_query($query);
	 //send the email
		$to = $email;
		$subject="notification From Pulcher Models Agency";
		$from = 'ntu2kotrevor@gmail.com';
		$body = "Testing sign_up function ";	
		
		$headers = "From: $from \r\n";
		$headers .= "Reply-To: $from \r\n";
		
		mail($to, $subject, $body,$headers);
	header("location: ../index.html");
}
}
}
?>

