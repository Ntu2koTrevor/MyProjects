<?php 
require "connect.php";

function createRandomPassword() {
					$chars = "abcdefghijkmnopqrstuvwxyz023456789";
					srand((double)microtime()*1000000);
					$i = 0;
					$pass = '' ;
					while ($i <= 7) {
						$num = rand() % 33;
						$tmp = substr($chars, $num, 1);
						$pass = $pass . $tmp;
						$i++;
					}
					return $pass;
				}
				$confirmation = createRandomPassword();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="generator" content="Adobe Dreamweaver Cs5">
    <meta name="description" content="Model agency ">
    <meta name="keywords" content="Modeling">
	<meta name="author" content="ET_IT">
    <meta name="robots" content="all">
    
 <link rel="stylesheet" type="text/css" href="../css/style_common.css" media="all"/>
 <link rel="stylesheet" type="text/css" href="../css/style10.css" media="all"/>
 <link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>   
<link rel="stylesheet" type="text/css" href="../style.css" media="all"/> 
<link rel="stylesheet" type="text/css" href="../css/Signup.css" media="all"/>  
<title>Sign Up</title>
<script type="text/javascript">

function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
function validateForm()
{
var a=document.forms["frmsearch"]["search_name"].value;
if (a==null || a=="")
  {
  alert("Your keyword must be 3 characters or more");
  return false;
  }
}
function validateForm1()
{
var a=document.forms["frmmembers"]["txtfname"].value;
if (a==null || a=="")
  {
  alert("Pls. Enter your FName");
  return false;
  }
  var a=document.forms["frmmembers"]["txtlname"].value;
if (a==null || a=="")
  {
  alert("Pls. Enter your LName");
  return false;
  }
  var a=document.forms["frmmembers"]["txtaddress"].value;
if (a==null || a=="")
  {
  alert("Pls. Enter your Address");
  return false;
  }
   var a=document.forms["frmmembers"]["txtcity"].value;
if (a==null || a=="")
  {
  alert("Pls. Enter your City");
  return false;
  }
   var a=document.forms["frmmembers"]["txtcountry"].value;
if (a==null || a=="")
  {
  alert("Pls. Enter your Country");
  return false;
  }
   var a=document.forms["frmmembers"]["txtnum"].value;
if (a==null || a=="")
  {
  alert("Pls. Enter your Contact Number");
  return false;
  }
  
var b=document.forms["frmmembers"]["txtmail"].value;
if (b==null || b=="")
  {
  alert("Pls. Enter your Email");
  return false;
  }
var c=document.forms["frmmembers"]["txtpass"].value;
if (c==null || c=="")
  {
  alert("Pls. Enter your Password");
  return false;
  }
var atpos=b.indexOf("@");
var dotpos=b.lastIndexOf(".");
if (atpos<1 || dotpos<atpos+2 || dotpos+2>=b.length)
  {
  alert("Not a valid e-mail address");
  return false;
  }
}
</script>
</head>
<body>
<div id="page">
<div id="header">
<div id="logo">
 <a href="../index.html"><img src="../images/Pulcher_Models2.jpg" width="300px" height="60px"></a>
</div><!-- /#logo-->
<form action="../Search.php" method="post" class="searchbar" name="frmsearch" onsubmit="return validateForm()">
				<input type="text" placeholder="Search Model" name="search_name">
				<input type="submit" value="Go">
			</form>
            
 <div id="signup">
<a href="Sign_up.php">Sign Up</a> <span>|</span> <a href="../userprofile.php">Log-in</a>
</div> <!-- /#signup -->     
</div><!-- /#header -->

<div id="navcontainer">
                        <ul id="navlist">
                        
                                <!-- CSS Tabs -->
<li><a  href="../index.html">Home</a></li>
<li><a href="../Women.php">Women</a></li>
<li><a href="../Men.php">Men</a></li>
<li><a href="../Registration/Become.php">Become</a></li>
<li><a href="../Contact.php">Contact Us</a></li>
<li><a href="../Entertainment.php">Entertainment</a></li>
                        </ul>
                
</div> <!-- /#nav-->   
<div class="become">
<div class="container" style="float: left; width:450px;">
		
			<span class="top-label">
				<span class="label-txt">Terms & Conditions</span>
			</span>
			
			<div class="content-area" style="border-radius:15px;">
            
            <p style="width:400px">As required by the Department of Employment regulations, the Agency's booking confirmation form, containing the specific terms of the booking, must be signed and returned by the client. The failure to sign and/or return the booking confirmation form whilst proceeding with the booking will be deemed to be an acceptance by the client of these terms and conditions and they shall apply to and govern the booking between the Agency and the client.

</p>
                  <p style="width:400px">Any amendment and/or variations made to the booking confirmation form by the client shall not be valid and binding unless the Agency has agreed to such amendment and/or variation in advance and confirmed such agreement by signing the booking confirmation form after the amendment and/or variation has been included on the booking confirmation form.
</p>
	
					
				

			</div>
		</div>

<div class="container" style="float:left; width: 212px; padding-bottom: 15px; margin-left: 100px;">
			<span class="top-label">
				<span class="label-txt">Personal Details</span>
			</span>
			<div class="content-area" style="border-radius:15px; padding-bottom: 25px;">
				<div>
            
 <form action="Sign_upexec.php" method="POST" enctype="multipart/form-data" name="frmmembers" onsubmit="return validateForm1()" >
                    <input type="hidden" name="txtid" value="<?php echo $confirmation ?>" />
First Name:<br />
<input type="text" name="txtfname" maxlength="15" placeholder="First Name" id="boxy" /><br />
Last Name:<br /> 
<input type="text" name="txtlname" maxlength="15" placeholder="Last Name" id="boxy" /><br />
Address:<br />
<input type="text" name="txtaddress" maxlength="30" placeholder="Address" id="boxy" /><br />
City:<br />
<input type="text" name="txtcity" maxlength="15" placeholder="City" id="boxy" /><br />
Country:<br /> 
<input type="text" name="txtcountry" maxlength="20" placeholder="Country" id="boxy" /><br />
Contact Number:<br />
<INPUT id="txtChar" onkeypress="return isNumberKey(event)" name="txtnum" maxlength="10" placeholder="Contact Number" /><br />
Email:<br />
<input type="text" name="txtmail" maxlength="50" placeholder="Email" id="boxy" /><br />
Password:<br />
<input type="password" name="txtpass" maxlength="20" placeholder="password" id="boxy" /><br />
<input type="submit" name="btnsubmit" value="Submit" id="boxy"  style="width: 147px; margin-top: 18px;"/> 
</form>
				</div>
			</div>
		</div>

</div>

<div id="contents">


<div id="footer">
<a  href="../index.html">Home</a><span>||</span>
<a  href="../About.php">About Us</a><span>||</span>
<a href="Become.php">Become</a><span>||</span>
<a href="../Contact.php">Contact Us</a>
 <p><a href="#"><img src="../images/social/001.bmp" /></a>&nbsp; &nbsp;<a href="#"><img src="../images/social/002.bmp" /></a>&nbsp; &nbsp;<a href="#"><img src="../images/social/003.png" /></a></p> 
	<p>Copyright&copy;2014 PulcherModels.com. All rights reserved.| Design by (ET_IT)</p>
</div><!-- /#footer--> 
</div><!-- /#contents--> 
</div><!-- /#page-->
</body>
</html>
