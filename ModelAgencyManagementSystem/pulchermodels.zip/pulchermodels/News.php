<?php 
require 'connect.php';
require_once'core.php';

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="generator" content="Adobe Dreamweaver Cs5">
    <meta name="description" content="Model agency ">
    <meta name="keywords" content="Modeling">
	<meta name="author" content="ET_IT">
    <meta name="robots" content="all">
    
<link rel="stylesheet" type="text/css" href="style.css" media="all"/> 
<link rel="stylesheet" type="text/css" href="css/News.css" media="all"/> 
<script type="text/javascript">
function validateForm()
{
var a=document.forms["frmsearch"]["search_name"].value;
if (a==null || a=="")
  {
  alert("Your keyword must be 3 characters or more");
  return false;
  }
}
</script>  
<title>News</title>
  

</head>
<body>
<div id="page">
<div id="header">
<div id="logo">
 <a href="index.html"><img src="images/Pulcher_Models2.jpg" width="300px" height="60px"></a>
</div><!-- /#logo-->
<form action="Search.php" method="post" class="searchbar" name="frmsearch" onsubmit="return validateForm()">
				<input type="text" placeholder="Search Model" name="search_name">
				<input type="submit" value="Go">
			</form>
            
 <div id="signup">
<a href="Registration/Sign_up.php">Sign Up</a> <span></span><span>|</span><a href="logout.php">Log-Out</a> <span></span>
</div> <!-- /#signup -->     
</div><!-- /#header -->

<div id="navcontainer">
                        <ul id="navlist">
                        
                                <!-- CSS Tabs -->
<li><a  href="userprofile.php">Profile</a></li>
<li><a href="News.php">News</a>

</li>
<li><a href="Fashion.php">Fashion</a></li>
<li><a href="Food.php">Food</a></li>
<li><a href="Event.php">Events</a></li>
<li><a href="Chatzone.php">Chat</a></li>
                        </ul>
                
</div> <!-- /#nav-->   


<?php 
echo '<div class="Newscontents">';
if (loggedin()) {
echo '<div class="box">';
echo '<div>';
echo '<div id="news" class="body">';
echo '<div class="sidebar">';
echo '<h3>Latest News</h3>';
echo '<ul>';
echo '<li>';
echo '<a href="News.php">2015 Bikini Contest Winners</a>';
'</li>';
echo '<li>';
echo '<a href="News.php">Trevor D in the Eat out commercial</a>';
echo '</li>';
echo '<li>';
echo '<a href="News.php">Fashion Week: Agencies show packages</a>';
echo '</li>';
echo '<li>';
echo '<a href="News.php">Model of week: Mbali Mavundla</a>';
echo '</li>';
echo '</ul>';
echo '<h3>Vaction Tips</h3>';
echo '<ul>';
echo '<li>';
echo '<a href="News.php">What to bring on the beach?</a>';
echo '</li>';
echo '<li>';
echo '<a href="News.php">Planning Fun Activities</a>';
echo '</li>';
echo '<li>';
echo '<a href="News.php">Diving Checklist</a>';
echo '</li>';
echo '<li>';
echo '<a href="News.php">First Aid</a>';
echo '</li>';
echo '<li>';
echo '<a href="News.php">How to Build a Sand Castle?</a>';
echo '</li>';
echo '<li>';
echo '<a href="News.php">Tanning Tips</a>';
echo '</li>';
echo '</ul>';
echo '</div>';
echo '<div>';
echo '<h1>News</h1>';
echo '<img src="images/News/Sydney.jpg" width="558" height="287" alt="Img" title="Sydney">';
echo '<h2>Sydney B with Premier Model Management, London!</h2>';
echo '<span class="time">June 03, 2015<br> by: Trevor October</span>';
echo '<p>';
echo 'Beautiful Sydney B will soon be flying off to London where she will be represented by one of the worlds top model agencys, Premier Model Management. Having represented top models such as Naomi Campbell and Evangelista, Sydney will definitely gain experience to launch her international career successfully! Knock em dead Sydney!
.';
echo '</p>';
echo '<img src="images/News/Devin.jpg" width="420" height="287" alt="Img" title="Devin">';
echo '<h2>Devin books Mens Health</h2>';
echo '<p>';
echo 'New to Twenty Model Management we are thrilled to have Devin book Mens Health SA and landing on the cover has made this gorgeous man a hot commodity you do not want to miss out on! Keep an eye out for Devin in the upcoming issue of Mens Health.
';
echo '</p>';

echo '</div>';
echo '</div>';
echo '</div>';
echo '</div>';

	

}else{
	
include 'loginform.php';	
}
echo '</div>';//<!-- /#News-->  
?>		
<div id="contents">


<div id="footer">
<a  href="index.html">Home</a><span>||</span>
<a  href="About.php">About Us</a><span>||</span>
<a href="Registration/Become.php">Become</a><span>||</span>
<a href="Contact.php">Contact Us</a>
 <p><a href="#"><img src="images/social/001.bmp" /></a>&nbsp; &nbsp;<a href="#"><img src="images/social/002.bmp" /></a>&nbsp; &nbsp;<a href="#"><img src="images/social/003.png" /></a></p> 
	<p>Copyright&copy;2014 PulcherModels.com. All rights reserved.| Design by (ET_IT)</p>
</div><!-- /#footer--> 
</div><!-- /#contents--> 
</div><!-- /#page-->
</body>
</html>


