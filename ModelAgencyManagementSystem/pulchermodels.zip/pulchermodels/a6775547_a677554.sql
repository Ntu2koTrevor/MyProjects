
-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 17, 2016 at 10:10 AM
-- Server version: 5.1.57
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `a6775547_a677554`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `UserName` varchar(50) NOT NULL,
  `Password` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` VALUES('admin', '81dc9bdb52d04dc20036dbd8313ed055');

-- --------------------------------------------------------

--
-- Table structure for table `become`
--

CREATE TABLE `become` (
  `id` varchar(10) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `age` int(2) NOT NULL,
  `height` int(4) NOT NULL,
  `dresssuitsize` int(3) NOT NULL,
  `waist` int(3) NOT NULL,
  `hips` int(3) NOT NULL,
  `eyescolor` varchar(10) NOT NULL,
  `haircolor` varchar(10) NOT NULL,
  `shoesize` int(3) NOT NULL,
  `bustchest` int(3) NOT NULL,
  `nationality` varchar(20) NOT NULL,
  `address` varchar(30) NOT NULL,
  `contactnum` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `fulllength` varchar(200) NOT NULL,
  `status` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `become`
--

INSERT INTO `become` VALUES('q2riwpti', 'Ntu2ko', 'Dlamini', 'Male', 24, 434, 32, 34, 33, 'black', 'xvxvxdd', 23, 34, 'sdsdsd', 'wdasdadsa', '3543435354', 'ntu2kotrevor@gmail.com', 'photos/IMG_0960-min.JPG', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `evdate` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` VALUES('1', 'cafe culture with Black Coffee', '6/6/2014');
INSERT INTO `events` VALUES('2', 'dbn july ziyawa', '6/6/2014');

-- --------------------------------------------------------

--
-- Table structure for table `frontend`
--

CREATE TABLE `frontend` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `frontend`
--

INSERT INTO `frontend` VALUES('frontend', 'pmfrontend');
INSERT INTO `frontend` VALUES('frontend', 'myfrontendpass1525');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` varchar(20) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `address` varchar(30) NOT NULL,
  `city` varchar(20) NOT NULL,
  `country` varchar(20) NOT NULL,
  `contactnum` varchar(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(250) NOT NULL,
  `profileimage` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` VALUES('kj7yo40p', 'Trevor', 'October', '161 Indlulamithi Rd Umlazi', 'DBN', 'SA', '0716299301', 'trevoroctober332@gmail.com', '477c87792fce364917e2fa042831f473', 'profilepic/2fc3b44.jpg');
INSERT INTO `members` VALUES('g337vjat', 'Scelo', 'Zulu', 'Po Box 16552 Mlazi 4000', 'Durban', 'South Africa', '0761224406', 'mg.mageba@gmail.com', 'c71fdacec4965b114d54042de60e25ca', 'profilepic/eNrTT87PLUjMq9Q3Mja20C8tyMlPTNE3T0wyTzFPTtPLKkhNB1wwxs4Lcg,,.jpeg');
INSERT INTO `members` VALUES('vokvoa67', 'rte', 'retert', 'ertertrt', 'erter', 'tertr', '2342342342', 'tre@gmai.com', '81dc9bdb52d04dc20036dbd8313ed055', 'profilepic/IMG_0960-min.JPG');
INSERT INTO `members` VALUES('au5s3z2h', 'rretert', 'ertertrter', 'cbvbcvb', 'fdhfdhdfh', 'dgvdfxgdfg', '1234567890', 'tee@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '');
INSERT INTO `members` VALUES('o3bcpjf7', 'Trevor', 'Dlamini', '1039', 'CPT', 'SA', '3453453535', 'ntu2kotrevor@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'profilepic/IMG_0960-min.JPG');
INSERT INTO `members` VALUES('2ib4d7ku', 'ssd', 'sdsd', '3 lane street', 'cape town', 'sa', '5646446556', 'denver@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '');

-- --------------------------------------------------------

--
-- Table structure for table `models`
--

CREATE TABLE `models` (
  `id` varchar(10) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `age` int(2) NOT NULL,
  `height` int(3) NOT NULL,
  `dressuitsize` int(3) NOT NULL,
  `waist` int(3) NOT NULL,
  `hips` int(3) NOT NULL,
  `eyescolor` varchar(10) NOT NULL,
  `haircolor` varchar(10) NOT NULL,
  `shoesize` int(3) NOT NULL,
  `bustchest` int(3) NOT NULL,
  `nationality` varchar(20) NOT NULL,
  `address` varchar(30) NOT NULL,
  `contactnum` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `status` varchar(15) NOT NULL,
  `profile` varchar(100) NOT NULL,
  `imageone` varchar(100) NOT NULL,
  `imagetwo` varchar(100) NOT NULL,
  `imagethree` varchar(100) NOT NULL,
  `imagefour` varchar(100) NOT NULL,
  `imagefive` varchar(100) NOT NULL,
  `videoname` varchar(200) NOT NULL,
  `url` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `models`
--

INSERT INTO `models` VALUES('2zf5gjim', 'Christoffer', 'Frolic', 'Male', 26, 183, 41, 81, 26, 'blue', 'dark brown', 9, 40, 'South African', '192 Smith street', '1234567890', 'trevoroctober332@gmail.com', 'Available', 'photos/013cf.jpg', 'photos/009cf.jpg', 'photos/016cf.jpg', 'photos/019cf.jpg', 'photos/012cf.jpg', 'photos/010cf.jpg', '', '');
INSERT INTO `models` VALUES('423rr7ti', 'Jule', 'Jule', 'Female', 25, 117, 36, 61, 91, 'blue/green', 'brown', 7, 33, 'South African', '192 Smith Street DBN', '1234567890', 'trevoroctober332@gmail.com', 'Available', 'photos/022.jpg', 'photos/018.jpg', 'photos/017.jpg', 'photos/020.jpg', 'photos/006.jpg', 'photos/001.jpg', '', '');
INSERT INTO `models` VALUES('4u3zp37s', 'David', 'david', 'Male', 30, 186, 42, 86, 25, 'brown', 'bald', 11, 40, 'South African', '192 Smith Street DBN', '1212121212', 'trevoroctober332@gmail.com', 'Available', 'photos/003dv.jpg', 'photos/005.jpg', 'photos/012dv.jpg', 'photos/001dv.jpg', 'photos/006dv.jpg', 'photos/002dv.jpg', '', '');
INSERT INTO `models` VALUES('6exqakdn', 'Alex', 'alex', 'Male', 26, 193, 30, 81, 50, 'brown', 'brown', 47, 25, 'South African', '192 Smith st DBN', '0987654321', 'trevoroctober332@gmail.com', 'Available', 'photos/003a.jpg', 'photos/009a.jpg', 'photos/018a.jpg', 'photos/001a.jpg', 'photos/029.jpg', 'photos/020a.jpg', '', '');
INSERT INTO `models` VALUES('86voo48v', 'Alyssa', 'alyssa', 'Female', 26, 178, 32, 61, 89, 'brown', 'brown', 6, 33, 'South African', '192 Smith st Dbn', '1234567890', 'trevoroctober332@gmail.com', 'Available', 'photos/032.jpg', 'photos/014.jpg', 'photos/011.jpg', 'photos/035.jpg', 'photos/038.jpg', 'photos/025.jpg', '', '');
INSERT INTO `models` VALUES('8nb8ko6o', 'Darren', 'darren', 'Male', 25, 185, 40, 84, 28, 'brown', 'bald', 10, 40, 'South African', '192 Smith st Dbn 4000', '2020983624', 'trevoroctober332@gmail.com', 'Available', 'photos/022d.jpg', 'photos/021d.jpg', 'photos/024d.jpg', 'photos/034d.jpg', 'photos/037d.jpg', 'photos/026d.jpg', '', '');
INSERT INTO `models` VALUES('hhjkxwq6', 'anna', 'anna', 'Female', 25, 178, 30, 60, 90, 'brown', 'black', 6, 32, 'south african', '192 Smith st Dbn', '0987654321', 'ntu2kotrevor@gmail.com', 'Available', 'photos/080.jpg', 'photos/083.jpg', 'photos/093.jpg', 'photos/107.jpg', 'photos/109.jpg', 'photos/087.jpg', '', '');
INSERT INTO `models` VALUES('ix5ovq3m', 'Akhona', 'Sibisi', 'Female', 23, 175, 30, 60, 84, 'Brown', 'Black', 5, 81, 'South African', '192 Smith Street DBN', '1234567890', 'trevoroctober332@gmail.com', 'Available', 'photos/002.jpg', 'photos/014as.jpg', 'photos/004as.jpg', 'photos/009as.jpg', 'photos/007as.jpg', 'photos/008as.jpg', '', '');
INSERT INTO `models` VALUES('k23uwfq7', 'Chris', 'chris', 'Male', 28, 189, 81, 74, 20, 'blue', 'brown', 11, 92, 'South African', '192 Smith st Durban', '1234567890', 'trevoroctober332@gmail.com', 'Available', 'photos/041.jpg', 'photos/038c.jpg', 'photos/028c.jpg', 'photos/042c.jpg', 'photos/027c.jpg', 'photos/032c.jpg', '', '');
INSERT INTO `models` VALUES('kj5y66h', 'Mbali', 'Mavundla', 'Female', 20, 80, 40, 35, 34, 'Blue', 'Black', 6, 7, 'African', '20 afrika Street ', '614758465', 'Nomusa@gmail.com', 'Available', 'photos/Mbali_Profile.JPG', 'photos/Img_01.JPG', 'photos/Img_02.jpg', 'photos/Img_03.jpg', 'photos/Img_04.jpg', 'photos/Img_05.jpg', '', '');
INSERT INTO `models` VALUES('ndvu5qbe', 'Bianca', 'Kayabe', 'Female', 21, 168, 28, 64, 92, 'brown', 'dark brown', 6, 81, 'South African', '192 Smith Street Durban', '0987654321', 'trevoroctober332@gmail.com', 'Available', 'photos/053.jpg', 'photos/029.jpg', 'photos/065.jpg', 'photos/062.jpg', 'photos/069.jpg', 'photos/066.jpg', '', '');
INSERT INTO `models` VALUES('rag6w3ru', 'Loyiso', 'mantanga', 'Male', 25, 185, 81, 81, 20, 'brown', 'black', 9, 90, 'South African', '192 Smith st Dbn', '1010101010', 'trevoroctober332@gmail.com', 'Available', 'photos/019l.jpg', 'photos/004l.jpg', 'photos/005l.jpg', 'photos/017l.jpg', 'photos/015l.jpg', 'photos/013l.jpg', '', '');
INSERT INTO `models` VALUES('ezr2d3b5', 'Regesh', 'Naidoo', 'Male', 25, 105, 32, 52, 91, 'Brown', 'black', 9, 30, 'SA', 'durban', '0761224406', 'naidoo@gmail.com', 'Available', '', '', '', '', '', '', '', '');
