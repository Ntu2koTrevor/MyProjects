<?php 
require "connect.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="generator" content="Adobe Dreamweaver Cs5">
    <meta name="description" content="Model agency ">
    <meta name="keywords" content="Modeling">
	<meta name="author" content="ET_IT">
    <meta name="robots" content="all">
    
 <link rel="stylesheet" type="text/css" href="css/style_common.css "media="all"/>
 <link rel="stylesheet" type="text/css" href="css/style10.css" media="all"/>
 <link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>   
<link rel="stylesheet" type="text/css" href="style.css" media="all"/>  
<link rel="stylesheet" type="text/css" href="css/Entertainment.css" media="all"/>  
<script type="text/javascript">
function validateForm()
{
var a=document.forms["frmsearch"]["search_name"].value;
if (a==null || a=="")
  {
  alert("Your keyword must be 3 characters or more");
  return false;
  }
}
</script> 
<title>Entertainment</title>

</head>
<body>
<div id="page">
<div id="header">
<div id="logo">
 <a href="index.html"><img src="images/Pulcher_Models2.jpg" width="300px" height="60px"></a>
</div><!-- /#logo-->
<form action="Search.php" method="post" class="searchbar" name="frmsearch" onsubmit="return validateForm()">
				<input type="text" placeholder="Search Model" name="search_name">
				<input type="submit" value="Go">
			</form>
            
 <div id="signup">
<a href="Registration/Sign_up.php">Sign Up</a> <span>|</span> <a href="userprofile.php">Log-in</a>
</div> <!-- /#signup -->     
</div><!-- /#header -->

<div id="navcontainer">
                        <ul id="navlist">
                        
                                <!-- CSS Tabs -->
<li><a  href="index.html">Home</a></li>
<li><a href="Women.php">Women</a></li>
<li><a href="Men.php">Men</a></li>
<li><a href="Registration/Become.php">Become</a></li>
<li><a href="Contact.php">Contact Us</a></li>
<li><a href="Entertainment.php">Entertainment</a></li>
                        </ul>
                
</div> <!-- /#nav-->   

<div class='Entercontent'>

<img src="images/Entertainment/entertainment.jpg" alt="Img" title="Entertainment">
			
<div id="main"> 
<div id="testimonials" class="box">
<div>
<div>
<h3> User Profile</h3>
<p>
"Information about an individual user, along with name, address, phone number, etc. it may include personal information. It contains user permissions and access settings." <span>- <a href="userprofile.php">User Profile</a></span>
</p>
<h3>News</h3>
<p>
"Information about recent events or happenings, especially as reported by newspapers, periodicals, radio or television. A presentation of such information, as in a newspaper or on a newscast." <span>- <a href="News.php">News</a></span>
</p>
<h3>Fashion</h3>
<p>
"As a fashion model you would promote clothing and accessories to fashion buyers, customers and the media. You might model items in fashion shows, or in photographs for catalogues, magazines, newspaper, and advertising campaigns. If you are interested in fashion and you look after your appearance, a job as model might suit you." <span>- <a href="Fashion.php">Fashion</a></span>
</p>
<h3>Food</h3>
<p>
"Food is any substance consumed to provide nutrition support for the body. It is usually of plant or animal origin and contains essential nutrients such as carbohydrates, fats, proteins, vitamins, or minerals." <span>- <a href="Food.php">Food</a></span>
</p>
<h3>Events</h3>
<p>
"Pulcher models is South African's most comprehensive events listing website. Everything you need to know about what's hot & happening in South Africa." <span>- <a href="Event.php">Events</a></span>
</p>
<h3>Chatzone</h3>
<p>
"Chat zone is designed for real-time, unstructured conversation with users who are signed on to the site at the same time." <span>- <a href="Chatzone.php">Chatzone</a></span>
</p>
</div>
</div>
</div>
</div>  
</div>


<div id="contents">


<div id="footer">
<a  href="index.html">Home</a><span>||</span>
<a  href="About.php">About Us</a><span>||</span>
<a href="Registration/Become.php">Become</a><span>||</span>
<a href="Contact.php">Contact Us</a>
 <p><a href="#"><img src="images/social/001.bmp" /></a>&nbsp; &nbsp;<a href="#"><img src="images/social/002.bmp" /></a>&nbsp; &nbsp;<a href="#"><img src="images/social/003.png" /></a></p> 
	<p>Copyright&copy;2014 PulcherModels.com. All rights reserved.| Design by (ET_IT)</p>
</div><!-- /#footer--> 
</div><!-- /#contents--> 
</div><!-- /#page-->
</body>
</html>

