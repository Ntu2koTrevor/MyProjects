<?php 
require "connect.php";


?>
<?php 

if (isset($_POST['btnsubmit'])){
if(isset($_POST['txtmail'])&&
isset($_POST['txtsub'])&&
isset($_POST['txtmsg']))



$name = mysql_real_escape_string($_POST['txtname']);
$email = mysql_real_escape_string($_POST['txtmail']);
$sub = mysql_real_escape_string($_POST['txtsub']);
$msg = mysql_real_escape_string($_POST['txtmsg']);

$to = "pulchermodels@gmail.com";
$subject = "$sub";
$from = "$email";
$body = "$msg"; 

mail($to,$subject,$body,$from);
header("location: index.html");

}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="generator" content="Adobe Dreamweaver Cs5">
    <meta name="description" content="Model agency ">
    <meta name="keywords" content="Modeling">
	<meta name="author" content="ET_IT">
    <meta name="robots" content="all">
    
 <link rel="stylesheet" type="text/css" href="../css/style_common.css">
 <link rel="stylesheet" type="text/css" href="../css/style10.css">
 <link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>   
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" type="text/css" href="css/Contact.css" />   
<title>Contact Us</title>
<script type="text/javascript">
function validateForm()
{
var a=document.forms["frmsearch"]["search_name"].value;
if (a==null || a=="")
  {
  alert("Your keyword must be 3 characters or more");
  return false;
  }
}
function validateForm1()
{
var a=document.forms["frmmail"]["txtname"].value;
if (a==null || a=="")
  {
  alert("Pls. Enter your Name");
  return false;
  }
  
var b=document.forms["frmmail"]["txtmail"].value;
if (b==null || b=="")
  {
  alert("Pls. Enter your Email");
  return false;
  }  
  var a=document.forms["frmmail"]["txtsub"].value;
if (a==null || a=="")
  {
  alert("Pls. Write a Subject");
  return false;
  }
  var a=document.forms["frmmail"]["txtmsg"].value;
if (a==null || a=="")
  {
  alert("Pls. Write a Message");
  return false;
  }
  
var atpos=b.indexOf("@");
var dotpos=b.lastIndexOf(".");
if (atpos<1 || dotpos<atpos+2 || dotpos+2>=b.length)
  {
  alert("Not a valid e-mail address");
  return false;
  }
}
</script>

</head>
<body>
<div id="page">
<div id="header">
<div id="logo">
 <a href="index.html"><img src="images/Pulcher_Models2.jpg" width="300px" height="60px"></a>
</div><!-- /#logo-->
<form action="Search.php" method="post" class="searchbar" name="frmsearch" onsubmit="return validateForm()">
				<input type="text" placeholder="Search Model" name="search_name">
				<input type="submit" value="Go">
			</form>
            
 <div id="signup">
<a href="Registration/Sign_up.php">Sign Up</a> <span>|</span> <a href="userprofile.php">Log-in</a>
</div> <!-- /#signup -->     
</div><!-- /#header -->

<div id="navcontainer">
                        <ul id="navlist">
                        
                                <!-- CSS Tabs -->
<li><a  href="index.html">Home</a></li>
<li><a href="Women.php">Women</a></li>
<li><a href="Men.php">Men</a></li>
<li><a href="Registration/Become.php">Become</a></li>
<li><a href="Contact.php">Contact Us</a></li>
<li><a href="Entertainment.php">Entertainment</a></li>
                        </ul>
                
</div> <!-- /#nav-->   
<div class="become">
<div class="container" style="float: left; width:250px;">
		
			<span class="top-label">
				<span class="label-txt">Contact Us</span>
			</span>
			
			<div class="content-area" style="border-radius:15px;">
            <p style="width:200px">
            <font face="Georgia, Times New Roman, Times, serif" color="#000000" size="+1">Trevor October (CEO)</font><br />
            <font face="Georgia, Times New Roman, Times, serif" color="#999999" size="3">trevoroctober332@gmail.com</font><br /> 
            <font face="Georgia, Times New Roman, Times, serif" color="#000000" size="+1">Women's Division</font><br />
            <font face="Georgia, Times New Roman, Times, serif" color="#999999" size="3">Sisipho Mangqishi</font><br />
            <font face="Georgia, Times New Roman, Times, serif" color="#000000" size="+1">Men's Division</font><br />
            <font face="Georgia, Times New Roman, Times, serif" color="#999999" size="3">Msawenkosi Zuma</font><br />
            <font face="Georgia, Times New Roman, Times, serif" color="#000000" size="+1">Office Administrator</font><br />
            <font face="Georgia, Times New Roman, Times, serif" color="#999999" size="2">Msawenkosi Zuma</font><br />
            <font face="Georgia, Times New Roman, Times, serif" color="#000000" size="+1">Accounts</font><br />
            <font face="Georgia, Times New Roman, Times, serif" color="#999999" size="3">Trevor October</font><br />
            <font face="Georgia, Times New Roman, Times, serif" color="#000000" size="+1">Address</font><br />
            <font face="Georgia, Times New Roman, Times, serif" color="#999999" size="3">Kwa-Zulu-Natal</font><br />
            <font face="Georgia, Times New Roman, Times, serif" color="#999999" size="3">Durban</font><br />
            <font face="Georgia, Times New Roman, Times, serif" color="#999999" size="3">4000 </font><br />
            <font face="Georgia, Times New Roman, Times, serif" color="#999999" size="3">South Africa</font><br /><br />
            <font face="Georgia, Times New Roman, Times, serif" color="#000000" size="3">Tel: +27 71 629 9301 </font><br />
            <font face="Georgia, Times New Roman, Times, serif" color="#000000" size="3">Phone: +27 84 828 0155 </font><br />
            </p>	
			</div>
		</div>

<div class="container" style="float:left; width: 412px; padding-bottom: 15px; margin-left: 420px;">
			<span class="top-label">
				<span class="label-txt">Email Us</span>
			</span>
			<div class="content-area" style="border-radius:15px; padding-bottom: 25px;">
		    <div> 
            <table>
            <form action="Contact.php" method="POST"  name="frmmail" onsubmit="return validateForm1()" >
                    
			
					
			<tr><td>Email:</td><td><input type="text" maxlength="30" name="txtmail" placeholder="Email" id="boxy" /></td></tr>
					
			<tr><td>Suject:</td><td><input type="text" maxlength="20" name="txtsub" placeholder="Subject" id="boxy" /></td></tr>
					
			<tr><td>Message:</td><td><textarea name="txtmsg" cols="20" rows="5" maxlength="50" placeholder="Type Message Here..." id="boxy" /></textarea></td></tr>
			<td></td><td>
		    <input type="submit" name="btnsubmit" value="Submit" id="boxy"  style="width: 147px; margin-top: 18px;"></td></tr>
            </form>
            </table>
                     
				</div>
			</div>
		</div>

</div>

<div id="contents">


<div id="footer">
<a  href="index.html">Home</a><span>||</span>
<a  href="About.php">About Us</a><span>||</span>
<a href="Registration/Become.php">Become</a><span>||</span>
<a href="Contact.php">Contact Us</a>
 <p><a href="#"><img src="images/social/001.bmp" /></a>&nbsp; &nbsp;<a href="#"><img src="images/social/002.bmp" /></a>&nbsp; &nbsp;<a href="#"><img src="images/social/003.png" /></a></p> 
	<p>Copyright&copy;2014 PulcherModels.com. All rights reserved.| Design by (ET_IT)</p>
</div><!-- /#footer--> 
</div><!-- /#contents--> 
</div><!-- /#page-->
</body>
</html>

