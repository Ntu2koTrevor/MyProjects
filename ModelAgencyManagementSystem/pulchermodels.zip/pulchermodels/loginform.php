<?php 

if (isset($_POST['username'])&&isset($_POST['password'])){
   $username = mysql_real_escape_string($_POST['username']);
   $password = mysql_real_escape_string($_POST['password']);
   $hash_pass = md5($password);
   
if (!empty($username)&&!empty($password)) {
	$query = "SELECT `id` FROM `members` WHERE `email`='$username' AND `password`='$hash_pass'";
     if ($query_run = mysql_query($query)) {
	$query_num_rows= mysql_num_rows($query_run);
	if ($query_num_rows==0) {
		echo 'Invalid username/password combination.';
	}else{
	$user_id = mysql_result($query_run, 0, 'id');
	$_SESSION['user_id']=$user_id;
	header('Location: userprofile.php');
	}
	 } 
}else {
	echo 'You must supply a username and password.';
}
}

?>
<form action="<?php echo $current_file; ?>" method="POST">
Email: <input type="text" name="username"> Password: <input type="password" name="password">
<input type="submit" value="Login">
</form>
<br />
<a href="recover.php" style="color:#6F6F6F" >Forgot Password?</a></style>