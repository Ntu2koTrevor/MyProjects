<?php 
require 'core.php';
require 'connect.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="generator" content="Adobe Dreamweaver Cs5">
    <meta name="description" content="Model agency ">
    <meta name="keywords" content="Modeling">
	<meta name="author" content="ET_IT">
    <meta name="robots" content="all">
    
 <link rel="stylesheet" type="text/css" href="css/Userprofile.css" media="all"/>    
 <link rel="stylesheet" type="text/css" href="style.css" media="all"/> 
 
<script type="text/javascript">
function validateForm()
{
var a=document.forms["frmsearch"]["search_name"].value;
if (a==null || a=="")
  {
  alert("Your keyword must be 3 characters or more");
  return false;
  }
}
</script>
<title>Profile</title>
  
</head>
<body>
<div id="page">
<div id="header">
<div id="logo">
 <a href="index.html"><img src="images/Pulcher_Models2.jpg" width="300px" height="60px"></a>
</div><!-- /#logo-->
<form action="Search.php" method="post" class="searchbar" name="frmsearch" onsubmit="return validateForm()">
				<input type="text" placeholder="Search Model" name="search_name">
				<input type="submit" value="Go">
			</form>
            
 <div id="signup">
<a href="Registration/Sign_up.php">Sign Up</a> <span></span><span>|</span><a href="logout.php">Log-Out</a> <span></span>
</div> <!-- /#signup -->     
</div><!-- /#header -->

<div id="navcontainer">
                        <ul id="navlist">
                        
                                <!-- CSS Tabs -->
<li><a  href="userprofile.php">Profile</a></li>
<li><a href="News.php">News</a>

</li>
<li><a href="Fashion.php">Fashion</a></li>
<li><a href="Food.php">Food</a></li>
<li><a href="Event.php">Events</a></li>
<li><a href="Chatzone.php">Chat</a></li>
                        </ul>
                
</div> <!-- /#nav-->   
<?php 


echo "<div class='userprof'>";
//whlie start
if (loggedin()) {
	$id = getuserfield('id');
	$fname = getuserfield('fname');
	$lname = getuserfield('lname');
	$address = getuserfield('address');
	$city = getuserfield('city');
	$country = getuserfield('country');
	$contactnum = getuserfield('contactnum');
	$email = getuserfield('email');
	
	//echo 'You\'re logged in, '.$firstname.' '.$surname.' <a href="logout.php">Log out</a><br>';
	echo '<div class="container" style="float: left; width:350px;">';
	echo '<span class="top-label">';
	echo '<span class="label-txt">Personal Details</span>';
	echo '</span>';
	echo '<div class="content-area" style="border-radius:15px;">';
	
	//echo 'You\'re logged in, '.$firstname.' '.$surname.' <a href="logout.php">Log out</a><br>';
	echo '<br>';
	echo "<font face='Georgia, Times New Roman, Times, serif' color='#000000' size='3'>" . 'Id : ' ."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#999999' size='+1'>" .$id;
	echo '<br>'.'<br>';
	echo "<font face='Georgia, Times New Roman, Times, serif' color='#000000' size='3'>" . 'First Name : ' ."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#999999' size='+1'>" .$fname;
	echo '<br>'.'<br>';
	echo "<font face='Georgia, Times New Roman, Times, serif' color='#000000' size='3'>" . 'Last Name : ' ."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#999999' size='+1'>" .$lname;
	echo '<br>'.'<br>';
	echo "<font face='Georgia, Times New Roman, Times, serif' color='#000000' size='3'>" . 'Address : ' ."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#999999' size='+1'>" .$address;
	echo '<br>'.'<br>';
	echo "<font face='Georgia, Times New Roman, Times, serif' color='#000000' size='3'>" . 'City : ' ."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#999999' size='+1'>" .$city;
	echo '<br>'.'<br>';
	echo "<font face='Georgia, Times New Roman, Times, serif' color='#000000' size='3'>" . 'Country : ' ."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#999999' size='+1'>" .$country;
	echo '<br>'.'<br>';
	echo "<font face='Georgia, Times New Roman, Times, serif' color='#000000' size='3'>" . 'Contact Number : ' ."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#999999' size='+1'>" .$contactnum;
	echo '<br>'.'<br>';
	echo "<font face='Georgia, Times New Roman, Times, serif' color='#000000' size='3'>" . 'Email : ' ."</font>"."<font face='Georgia, Times New Roman, Times, serif' color='#999999' size='+1'>" .$email;
	echo '</div>';
	echo '</div>';
	
	echo '<div class="container" style="float: left; width: 350px; padding-bottom: 15px; margin-left: 380px;">';
	echo '<span class="top-label">';
	echo '<span class="label-txt">Profile Picture</span>';
	echo '</span>';
	echo '<div class="content-area" style="border-radius:15px; padding-bottom: 25px;">';
	
	//echo '<div class="container">';
	//echo '<div class="main">';
	echo '<div class="view1 view-tenth1">';
	if(getuserfield('profileimage') ==""){
echo "<img height='300' width='300' src='images/Default/default-medium.png' alt=Default Profile pic' Profile pic' title='Default image'>";
}else{
echo "<img height='300' width='300' src='".getuserfield('profileimage')."' alt='Preview'>";	                                   
}	
	
	echo '</div>';
	echo '<a href=editprofilepic.php?id=' . $id . '>' . 'Change Profile Pic' . '</a>';	
	echo '</div>';
	echo '</div>';

}else{
	
include 'loginform.php';	
}
echo '</div>';//div container			
?> 
<div id="contents">


<div id="footer">
<a  href="index.html">Home</a><span>||</span>
<a  href="About.php">About Us</a><span>||</span>
<a href="Registration/Become.php">Become</a><span>||</span>
<a href="Contact.php">Contact Us</a>
 <p><a href="#"><img src="images/social/001.bmp" /></a>&nbsp; &nbsp;<a href="#"><img src="images/social/002.bmp" /></a>&nbsp; &nbsp;<a href="#"><img src="images/social/003.png" /></a></p> 
	<p>Copyright&copy;2014 PulcherModels.com. All rights reserved.| Design by (ET_IT)</p>
</div><!-- /#footer--> 
</div><!-- /#contents--> 
</div><!-- /#page-->
</body>
</html>


