<?php 
require "connect.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="generator" content="Adobe Dreamweaver Cs5">
    <meta name="description" content="Model agency ">
    <meta name="keywords" content="Modeling">
	<meta name="author" content="ET_IT">
    <meta name="robots" content="all">
    
 <link rel="stylesheet" type="text/css" href="css/style_common.css" media="all"/>
 <link rel="stylesheet" type="text/css" href="css/style10.css" media="all"/>
 <link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>   
<link rel="stylesheet" type="text/css" href="style.css" media="all"/> 
<script type="text/javascript">
function validateForm()
{
var a=document.forms["frmsearch"]["search_name"].value;
if (a==null || a=="")
  {
  alert("Your keyword must be 3 characters or more");
  return false;
  }
}
</script>  
<title>Men</title>
<style type="text/css">
	  
	  .imagecontainer{
	display: inline-block;
	width:1090px;
	margin-bottom: 30px;
	margin-top:20px;
}
</style> 
</head>
<body>
<div id="page">
<div id="header">
<div id="logo">
 <a href="index.html"><img src="images/Pulcher_Models2.jpg" width="300px" height="60px"></a>
</div><!-- /#logo-->
<form action="Search.php" method="post" class="searchbar" name="frmsearch" onsubmit="return validateForm()">
				<input type="text" placeholder="Search Model" name="search_name">
				<input type="submit" value="Go">
			</form>
            
 <div id="signup">
<a href="Registration/Sign_up.php">Sign Up</a> <span>|</span> <a href="userprofile.php">Log-in</a>
</div> <!-- /#signup -->     
</div><!-- /#header -->

<div id="navcontainer">
                        <ul id="navlist">
                        
                                <!-- CSS Tabs -->
<li><a  href="index.html">Home</a></li>
<li><a href="Women.php">Women</a></li>
<li><a href="Men.php">Men</a></li>
<li><a href="Registration/Become.php">Become</a></li>
<li><a href="Contact.php">Contact Us</a></li>
<li><a href="Entertainment.php">Entertainment</a></li>
                        </ul>
                
</div> <!-- /#nav-->   
<?php 
$query = mysql_query("SELECT * FROM models WHERE gender='Male' || gender='male'");




echo "<div class='imagecontainer'>";
while($row = mysql_fetch_assoc($query)){
	
$id = $row['id'];
$fname = $row['fname'];

$height = $row['height'];
$waist = $row['waist'];	
$hips = $row['hips'];
echo "<div class='container'>";
           
           echo "<div class='main'>"; 
                
              echo  "<div class='view view-tenth'>";
                if($row['profile'] ==""){
                                    echo "<img width='300' height='300' src='images/Default/default-medium.png' alt=Default Profile pic' Profile pic' title='Default image'>";
                                    }else{
                                    echo "<img width='300' height='300' src='Admin/".$row['profile']."' alt=Preview'>";	
                                    }
                 
                   echo "<div class='mask'>";
                       echo  "<h2>Name :$fname</h2>";
                        echo "<p>";
						echo "Height :";
						  echo $height;
						echo "<br>";
						echo "Waist :";
						  echo $waist;
						echo "<br>";
						echo "Hips :";
						  echo $hips;
						echo "<p>";
                       
                    // echo "<a href='#' class='info'>View More</a>";
				echo '<a href=model_profile.php?id=' . $row['id'] . ' class="info">' . 'View More' . '</a>';
                  echo  "</div>";
               echo  "</div>";
               
       echo "</div>";
	
       echo "<script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js'></script>";

echo "</div>";
}
?> 
<div id="contents">


<div id="footer">
<a  href="index.html">Home</a><span>||</span>
<a  href="About.php">About Us</a><span>||</span>
<a href="Registration/Become.php">Become</a><span>||</span>
<a href="Contact.php">Contact Us</a>
 <p><a href="#"><img src="images/social/001.bmp" /></a>&nbsp; &nbsp;<a href="#"><img src="images/social/002.bmp" /></a>&nbsp; &nbsp;<a href="#"><img src="images/social/003.png" /></a></p> 
	<p>Copyright&copy;2014 PulcherModels.com. All rights reserved.| Design by (ET_IT)</p>
</div><!-- /#footer--> 
</div><!-- /#contents--> 
</div><!-- /#page-->
</body>
</html>
