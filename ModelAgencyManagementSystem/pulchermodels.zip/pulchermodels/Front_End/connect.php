<?php
$conn_error='Could not connect.';

$mysql_host='mysql6.000webhost.com';
$mysql_user='a6775547_a677554';
$mysql_pass='trevor332';

$mysql_db='a6775547_a677554';

if (!@mysql_Connect($mysql_host, $mysql_user, $mysql_pass) ||!@mysql_select_db($mysql_db)){
die($conn_error);
}
?> 