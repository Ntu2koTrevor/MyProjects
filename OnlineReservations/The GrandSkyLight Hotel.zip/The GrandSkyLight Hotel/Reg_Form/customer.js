function Customervalidation(){
		 if(document.getElementById('txtTitle').value.length==0){
		 document.getElementById('title').innerHTML="Title field is empty";
	return false;
	return true;
}
 
 else if(document.getElementById('txtFirstName').value.length==0){
		 document.getElementById('Fname').innerHTML="First name field is empty";
	return false;
	return true;
}

else if(document.getElementById('txtLastName').value.length==0){
		 document.getElementById('Lname').innerHTML="Last name field is empty";
	return false;
	return true;
}
 
 else if(document.getElementById('txtAddress').value.length==0){
		 document.getElementById('address').innerHTML="Address field is empty";
	return false;
	return true;
}
 else if(document.getElementById('txtCity').value.length==0){
		 document.getElementById('city').innerHTML="Input City";
	return false;
	return true;
}

 else if(document.getElementById('txtCountry').value.length==0){
		 document.getElementById('country').innerHTML="Country field is empty";
	return false;
	return true;
}

 else if(document.getElementById('txtPostalCode').value.length==0){
		 document.getElementById('postal').innerHTML="Please input Postal Code";
	return false;
	return true;
}

else if(document.getElementById('txTPhoneNumber').value.length==0){
		 document.getElementById('phone').innerHTML="Phone field is empty";
	return false;
	return true;
}

else if(document.getElementById('txtNationality').value.length==0){
		 document.getElementById('nationality').innerHTML="Nationality field is empty";
	return false;
	return true;
}

else if(document.getElementById('txtEmail').value.length==0){
		 document.getElementById('email').innerHTML="Email field is empty";
	return false;
	return true;
}

else var x=document.forms["CUSTOMER DETAILS FORM"]["txtEmail"].value;
var atpos=x.indexOf("@");
var dotpos=x.lastIndexOf(".");
if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length)
  {
  alert("The e-mail address you have entered is not Valid");
  return false;
}

else if(document.getElementById('PaymentMethod').selectedIndex==0){
		 document.getElementById('pay').innerHTML="Please select payment method";
	return false;
	return true;
}
 
 else if(document.getElementById('T&Cs').checked==0){
		 document.getElementById('chk').innerHTML="Terms & Conditions are ignored";
	return false;
	return true;
}
 
 }