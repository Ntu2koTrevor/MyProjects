function Roomsvalidation(){
	if(document.getElementById('Room Type').selectedIndex==0){
	alert("Please Select a Room");
	return false;
}

else if(document.getElementById('txtRoom_Number').value.length==0){
	alert("Please input the room number");
	return false;
}


else if(document.getElementById('Floor').selectedIndex==0){
	alert("Please Select the floor");
	return false;
}

else if(document.getElementById('txtAmount').value.length==0){
	alert("Please input amount");
	return false;
}


}
