<?php
	//require_once('../auth.php');
?>
<html>
<head>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="febe/style.css" type="text/css" media="screen" charset="utf-8">
<script src="argiepolicarpio.js" type="text/javascript" charset="utf-8"></script>
<script src="js/application.js" type="text/javascript" charset="utf-8"></script>	
</head>
<body>
	<div id="container">
		<div id="adminbar-outer" class="radius-bottom">
			<div id="adminbar" class="radius-bottom">
				<a id="logo" href="Admin_Page.php"></a>
				<div id="details">
					<a class="avatar" href="javascript: void(0)">
					<img width="36" height="36" alt="avatar" src="img/avatar.jpg">
					</a>
					<div class="tcenter">
					Hi
					<strong>Admin</strong>
					!
					<br>
					<a class="alightred" href="../index.php">Logout</a>
					</div>
				</div>
			</div>
		</div>
		<div id="panel-outer" class="radius" style="opacity: 1;">
			<div id="panel" class="radius">
				<ul class="radius-top clearfix" id="main-menu">
					<li>
						<a class="active" href="Reservations.php">
							<img alt="Reservations" src="img/reservationLogo.bmp">
							<span>Reservations</span>
						</a>
					</li>
					<li>
						<a href="Custormers.php">
							<img alt="Custormers" src="img/CustomerLogo.bmp">
							<span>Custormers</span>
							<span class="submenu-arrow"></span>
						</a>
					</li>
					<li>
						<a href="Rooms.php">
							<img alt="Rooms" src="img/roomsLogo.bmp">
							<span>Rooms</span>
							<span class="submenu-arrow"></span>
						</a>
					</li>
					<li>
						<a href="Conference_Facility.php">
							<img alt="Conference Facility" src="img/conferenceLogo.bmp">
							<span>Conference Facility</span>
						</a>
					</li>
					
					<div class="clearfix"></div>
				</ul>
				<div id="content" class="clearfix">
					
					<table cellpadding="1" cellspacing="1" id="resultTable">
						<thead>
							<tr>
								
								<th style="border-left: 1px solid #C1DAD7">Title</th>
                                <th>First_Name</th>
								<th>Last_Name</th>
								<th>Address</th>
								<th>City</th>
                                <th>Country</th>
								<th>Postal_Code</th>
								<th>Phone_No</th>
								<th>Confirmation</th>
                                <th>E-Mail Address</th>
								<th>Payment_Method</th>
							</tr>
						</thead>
						<tbody>
						<?php
							include('connect.php');
							/*$conn_error='Could not connect.';
	                        $mysql_host='localhost';
	                        $mysql_user='root';
	                        $mysql_pass='';
	                        $mysql_db='thegslh_managementsystem';
	                        if (!@mysql_Connect($mysql_host, $mysql_user, $mysql_pass) ||!@mysql_select_db($mysql_db)){
	                        die($conn_error);
	                         }*/
							$result = mysql_query("SELECT *FROM customer_details");
							while($row = mysql_fetch_array($result))
								{
									echo '<tr class="record">';
									
									echo '<td style="border-left: 1px solid #C1DAD7;">'.$row['Title'].'</div></td>';
									echo '<td><div align="right">'.$row['First_Name'].'</div></td>';
									echo '<td><div align="right">'.$row['Last_Name'].'</div></td>';
									echo '<td><div align="right">'.$row['Address'].'</div></td>';
									echo '<td><div align="right">'.$row['City'].'</div></td>';
									echo '<td><div align="right">'.$row['Country'].'</div></td>';
									echo '<td><div align="right">'.$row['Postal_Code'].'</div></td>';
									echo '<td><div align="right">'.$row['Phone_No'].'</div></td>';
									echo '<td><div align="right">'.$row['Confirmation'].'</div></td>';
									echo '<td><div align="right">'.$row['Email'].'</div></td>';
									echo '<td><div align="right">'.$row['PaymentMethod'].'</div></td></tr>';
								}
							?> 
						</tbody>
					</table>
				</div>
				<div id="footer" class="radius-bottom">
					2013©
					<a class="afooter-link" href="#">The GrandSkyLight Hotel</a>
					by
					<a class="afooter-link" href="#">Think Tank Software Solutions</a>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
	</div>
</body>
</html>