<?php

define('INCLUDE_CHECK',1);
require "connect.php";
function createRandomPassword() {
					$chars = "abcdefghijkmnopqrstuvwxyz023456789";
					srand((double)microtime()*1000000);
					$i = 0;
					$pass = '' ;
					while ($i <= 7) {
						$num = rand() % 33;
						$tmp = substr($chars, $num, 1);
						$pass = $pass . $tmp;
						$i++;
					}
					return $pass;
				}
				$confirmation = createRandomPassword();
?>
<?php
	$arival = $_POST['start'];
	$departure = $_POST['end'];
	$numberofnights = $_POST['result'];
	
	
	
?>


<!DOCTYPE html>
<html>
<head>
<title>The GrandSkyLight Hotel_Room Info Form</title>


<SCRIPT language=Javascript>
      <!--
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
	  
	  function setNumOfNights()
	  {
		 var totalCost=0;
		 var roomType=document.checkoutForm.Room_Type.value;
		 var numOfRooms=document.checkoutForm.txtRooms.value;
		 var numNights=document.checkoutForm.numnights.value;
		 
		 if(roomType=="SingleRoom")
		 {
		 	totalCost=numOfRooms*numNights*250;
		 }
		 else if(roomType=="DoubleRoom")
		 {
			 totalCost=numOfRooms*numNights*500;
		 } 
		 else if(roomType=="SuitRoom")
		 {
			  totalCost=numOfRooms*numNights*750;
		 } 
		 else if(roomType=="DeluxRoom")
		 {
			  totalCost=numOfRooms*numNights*1000;
		 } 
		 else
		 {
			//document.getElementById('sltRoomType').innerHTML.backgroundcolor.value="red";
			//alert("Please make sure you selected the room type!!");
		 } 
		 document.checkoutForm.txtTotal.value="R" + totalCost;
	  }
	  
      //-->
   </SCRIPT>
</head>
<body background="bg01.png">
<h2>ROOMS INFORMATION</h2>

<form name="checkoutForm" method="post" action="ReservationDetails.php">
<input name="start" type="hidden" value="<?php echo $arival; ?>" />
<input name="end" type="hidden" value="<?php echo $departure; ?>" />
<input name="numnights" type="hidden" value="<?php echo $numberofnights; ?>" />
<input type="hidden" name="confirmation" value="<?php echo $confirmation ?>" />
<table>
<tr>
<td>ROOM TYPE:</td><td>
<select id="sltRoomType" name="Room_Type">
<option value="SelectRoom">Select Room</option>
<option value="SingleRoom">Single Room R250</option>
<option value="DoubleRoom">Double Room R500</option>
<option value="SuitRoom">Suit Room R750</option>
<option value="DeluxRoom">Delux Room R1000</option>
</select></td>
</tr>
<tr>
<td>ROOMS:</td><td><INPUT id="txtChar" onBlur="setNumOfNights()" tabindex="1" onkeypress="return isNumberKey(event)" type="text" name="txtRooms" class="ed"></td>

</tr>
<tr>
<td>FLOOR:</td><td>
<select id="Floor" name="Floor">
<option>Select Floor</option>
<option value="First Floor">First Floor</option>
<option value="Second Floor">Second Floor</option>
<option value="Third Floor">Third Floor</option>
<option value="Forth Floor">Forth Floor</option>
<option value="Fifth Floor">Fifth Floor</option>
</select></td>
<tr>
<td>TOTAL:</td><td><input type="text" onFocus="setNumOfNights()" name="txtTotal" id="txtTotal" ></td>
</tr>
<tr>
<td>
<h2>CUSTOMER DETAILS</h2></td>
</tr>
<tr>
<td>TITLE:</td><td><input type="text" name="txtTitle" id="txtTitle"><span style="color:red;">*</span>
<span id="title" style="color:#F00; position:relative; bottom:5px; left:0px;"></span></td>
</tr>
<tr>
<td>FIRST NAME:</td><td><input type="text" name="txtFirstName" id="txtFirstName"><span style="color:red;">*</span>
<span id="Fname" style="color:#F00; position:relative; bottom:5px; left:0px;"></span></td>
</tr>
<tr>
<td>LAST NAME:</td><td><input type="text" name="txtLastName" id="txtLastName"><span style="color:red;">*</span>
<span id="Lname" style="color:#F00; position:relative; bottom:5px; left:0px;"></span></td>
<tr>
<td>ADDRESS:</td><td><input type="text" name="txtAddress" id="txtAddress"><span style="color:red;">*</span>
<span id="address" style="color:#F00; position:relative; bottom:5px; left:0px;"></span></td>
</tr>
<tr>
<td>CITY:</td><td><input type="text" name="txtCity" id="txtCity"><span style="color:red;">*</span>
<span id="city" style="color:#F00; position:relative; bottom:5px; left:0px;"></span></td>
</tr>
<tr>
<td>COUNTRY:</td><td><input type="text" name="txtCountry" id="txtCountry"><span style="color:red;">*</span>
<span id="country" style="color:#F00; position:relative; bottom:5px; left:0px;"></span></td>
</tr>
<tr>
<td>POSTAL CODE:</td><td><INPUT id="txtChar" onkeypress="return isNumberKey(event)" type="text" name="txtPostalCode" class="ed"><span style="color:red;">*</span>
<span id="postal" style="color:#F00; position:relative; bottom:5px; left:0px;"></span></td>
</tr>
<tr>
<td>PHONE NO:</td><td><INPUT id="txtChar" onkeypress="return isNumberKey(event)" type="text" name="txTPhoneNumber" class="ed"><span style="color:red;">*</span>
<span id="phone" style="color:#F00; position:relative; bottom:5px; left:0px;"></span></td>
</tr>

<tr>
<td>E-MAIL ADDRESS:</td><td><input type="text" name="txtEmail" id="txtEmail"><span style="color:red;">*</span>
<span id="email" style="color:#F00; position:relative; bottom:5px; left:0px;"></span></td>
</tr>
<tr>
<td>PAYMENT METHOD:</td><td>
<select name="PaymentMethod" id="PaymentMethod">
<option>[Select Payment]</option>
<option value="Manual">Manual</option>
<option value="Debit card">Debit card</option>
<option value="Credit card">Credit card</option>
<option value="Cheque">Cheque</option>
<option value="On arrival">On arrival</option>
</select><span id="pay" style="color:#F00; position:relative; bottom:5px; left:0px;"></span></td>
</tr>
<tr>
<td></td><td><input type="checkbox" name="T&Cs" id="T&Cs">I agree with the<a href="TandCs.html"> terms & conditions</a>
<span id="chk" style="color:#F00; position:relative; bottom:0px; left:0px;"></div></td>
</tr>
<tr>
<td>
<span><input type="submit" onclick="document.forms.checkoutForm.submit(); return false;" value="Continue" style="height: 34px; margin-left: 15px; width: 191px; padding: 5px; border: 3px double rgb(204, 204, 204);" /></span>
</td>
</tr>
</table>
</form>
</body>
</html>