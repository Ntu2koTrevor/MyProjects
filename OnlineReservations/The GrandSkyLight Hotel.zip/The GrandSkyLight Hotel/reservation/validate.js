function validateForm()
{
if(document.getElementById('txtDate').value.length==0){
	alert("Date Field is blank");
	return false;
}


else if(document.getElementById('txtFirstName').value.length==0){
	alert("First name Field is blank");
	return false;
}


else if(document.getElementById('txtLastName').value.length==0){
	alert("Last name Field is blank");
	return false;
	
}

else if(document.getElementById('txtDuration_Hours').value.length==0){
	alert("Please input Hours");
	return false;
}

else if(document.getElementById('Hall_No').selectedIndex==0){
	alert("Please select Hall number");
	return false;
}

else if(document.getElementById('txtAmount').value.length==0){
	alert("Amount Field is blank");
	return false;
}

else if(document.getElementById('PaymentMethod').selectedIndex==0){
	alert("Please select Payment Method");
	return false;
}

}