<?php

define('INCLUDE_CHECK',1);
require "connect.php";
function createRandomPassword() {
					$chars = "abcdefghijkmnopqrstuvwxyz023456789";
					srand((double)microtime()*1000000);
					$i = 0;
					$pass = '' ;
					while ($i <= 7) {
						$num = rand() % 33;
						$tmp = substr($chars, $num, 1);
						$pass = $pass . $tmp;
						$i++;
					}
					return $pass;
				}
				$confirmation = createRandomPassword();
?>

<html>
<head>
<title>The GrandSkyLight Hotel_Conference Facility Form</title>
<SCRIPT language=Javascript>
      <!--
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
	   function setHoursPerDay()
	  {
		 var totalCost=0;
		 var duration=document.ConferenceFacilityForm.txtDuration_Hours.value;
		 var hallno=document.ConferenceFacilityForm.Hall_No.value;
		
		 if(hallno=="HallOne")
		 {
		 	totalCost=duration*3500;
		 }
		 else if(hallno=="HallTwo")
		 {
			 totalCost=duration*5000;
		 } 
		 else if(hallno=="HallThree")
		 {
			  totalCost=duration*7500;
		 } 
		 else if(hallno=="HallFour")
		 {
			  totalCost=duration*10000;
		 } 
		 else if(hallno=="HallFive")
		 {
			  totalCost=duration*13500;
		 } 
		 else
		 {
			//document.getElementById('sltRoomType').innerHTML.backgroundcolor.value="red";
			//alert("Please make sure you selected the room type!!");
		 } 
		 document.ConferenceFacilityForm.txtAmount.value="R" + totalCost;
	  }
	  //-->
	  </script>
<script language="javascript" src="validate.js"></script>
</head>
<body background="bg01.png">
<h2>CONFERENCE FACILITY FORM</h2><br>

<form action="ConferenceFacilityReservationDetails.php" method="POST" name="ConferenceFacilityForm" accept-charset="utf-8" onSubmit="return validateForm();">
<input type="hidden" name="confirmation" value="<?php echo $confirmation ?>" />
<table>
<tr>
<td>DATE:</td><td><input type="text" id="txtDate" name="txtDate"></td><td><b>ACCOUNT DETAILS</b></td>
</tr>
<tr>
<td>FIRST NAME:</td><td><input type="text" id="txtFirstName" name="txtFirstName"></td><td>AMOUNT:</td><td><input type="text" id="txtAmount" onFocus="setHoursPerDay()" name="txtAmount"></td>
</tr>
<tr>
<td>LAST NAME:</td><td><input type="text" id="txtLastName" name="txtLastName"></td><td>PAYMENT METHOD:</td>
<td>
<select id="PaymentMethod" name="PaymentMethod">
<option>Payment Method</option>
<option value="manual">Manual</option>
<option value="Debit card">Debit card</option>
<option value="Credit card">Credit card</option>
<option value="Cheque">Cheque</option></select></td>
</tr>
<tr>
<td>HALL NO:</td><td>
<select id="Hall_No" name="Hall_No">
<option value="Select Hall_No">Select Hall_No</option>
<option value="HallOne">Hall_1_R3500</option>
<option value="HallTwo">Hall_2_R5000</option>
<option value="HallThree">Hall_3_R7500</option>
<option value="HallFour">Hall_4_R10000</option>
<option value="HallFive">Hall_5_R13000</option>
</select></td>
</tr>
<tr>
<td>DURATION/HOURS:</td><td><INPUT id="txtChar" onBlur="setHoursPerDay()" tabindex="1" onKeyPress="return isNumberKey(event)" type="text" name="txtDuration_Hours" class="ed"></td>
</tr>
<tr>
<td></td><td><span><input type="submit" onClick="document.forms.ConferenceFacilityForm.submit(); return false;" value="Submit" style="height: 34px; margin-left: 1px; width: 191px; padding: 1px; border: 3px double rgb(204, 204, 204);" /></span>

<span><input type="Reset" name="btnCancel" value="Cancel" style="height: 34px; margin-left: 15px; width: 191px; padding: 5px; border: 3px double rgb(204, 204, 204);"/></span>
</td>
</tr>
</table>
</form>

<a href="../Weddings_Events.html">Back to Weddings and Events</a>


</body>
</html>