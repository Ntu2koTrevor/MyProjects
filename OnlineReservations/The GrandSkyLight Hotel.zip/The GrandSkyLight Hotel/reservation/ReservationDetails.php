<?php

define('INCLUDE_CHECK',1);
require "connect.php";

if(!$_POST)
{
	if($_SERVER['HTTP_REFERER'])
	header('Location : '.$_SERVER['HTTP_REFERER']);
	
	exit;
}

?>

<!DOCTYPE html>
<html>
<head>
<title>The GrandSkyLight Hotel_Reservation Details Form</title>
</head>
<body background="bg01.png">

 <?php
				$arival=$_POST['start'];
				$departure=$_POST['end'];
				$numnights=round($_POST['numnights']);
				$RoomType=$_POST['Room_Type'];
				$Rooms=$_POST['txtRooms'];
				$Floor=$_POST['Floor'];
				$Total=$_POST['txtTotal'];
				$confirmation = $_POST['confirmation'];
				
				$title=$_POST['txtTitle'];
				$fname=$_POST['txtFirstName'];
				$lname=$_POST['txtLastName'];
				$address=$_POST['txtAddress'];
				$city= $_POST['txtCity'];
				$country=$_POST['txtCountry'];
				$postalcode=$_POST['txtPostalCode'];
				$phone=$_POST['txTPhoneNumber'];
				$email = $_POST['txtEmail'];
				$paymentmethode= $_POST['PaymentMethod'];
				
				//send the email
		/*$to = $email;
		$subject="Reservation notification From The Grandskylight Hotel";
		$from = 'thegrandskylight@gmail.com';
		$body = "CheckInDate: $arival\n".
		"CheckOutDate: $departure\n".
		"Numnights: $numnights \n".
		"Rooms: $Rooms \n".
		"Room_Type: $RoomType \n".
		"Gross_Total: $Total \n".
		"Confirmation: $confirmation\n ";	
		
		$headers = "From: $from \r\n";
		$headers .= "Reply-To: $$from \r\n";
		
		mail($to, $subject, $body,$headers);*/
				
				
					
						$ins="INSERT INTO reservation_details(CheckInDate,CheckOutDate,Numnights,Rooms,Room_Type,Gross_Total,Confirmation) VALUES('$arival','$departure','$numnights','$Rooms','$RoomType','$Total','$confirmation')";
						
						
						
						$ins2="INSERT INTO customer_details(Title, First_Name,Last_Name,Address,City,Country,Postal_Code,Phone_No,Confirmation,Email,PaymentMethod) VALUES('$title','$fname','$lname','$address','$city','$country','$postalcode','$phone','$confirmation','$email','$paymentmethode')";
						
						$ins3="INSERT INTO rooms_info(Room_Type,Rooms,Floor,Total,Confirmation) VALUES('$RoomType','$Rooms','$Floor','$Total','$confirmation')";
						
						mysql_query($ins);
						mysql_query($ins2);
						mysql_query($ins3);
						echo mysql_error();
				
?>
                <h1>Reservation details:</h1>
                <h3>Check In:<?php echo $arival ?></h3>
				<h3>Check Out: <?php echo $departure ?></h3>
				<h3>Number Of Nights: <?php echo $numnights ?></h3>
                
                <h3>Room Type:<?php echo $RoomType ?></h3>
				<h3>Rooms: <?php echo $Rooms ?></h3>
				<h3>Floor: <?php echo $Floor ?></h3>
				<h3>Total: <?php echo $Total ?></h3>
				<h3>Confirmation: <?php echo $confirmation ?></h3>
                
                <h1>Customer Details:</h1>
                <h3>Title:<?php echo $title ?></h3>
				<h3>Fname: <?php echo $fname ?></h3>
                <h3>Lname: <?php echo $lname ?></h3>
				<h3>Address: <?php echo $address ?></h3>
                
                <h3>City:<?php echo $city ?></h3>
				<h3>Country: <?php echo $country ?></h3>
				<h3>Postal Code: <?php echo $postalcode ?></h3>
				<h3>Phone: <?php echo $phone ?></h3>
				<h3>Email: <?php echo $email ?></h3>
				<h3>Payment Methode: <?php echo $paymentmethode ?></h3>
               Click<a href="savingreservation.php"> here</a> to save reservations
</body>
</html>