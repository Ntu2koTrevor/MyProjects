<?php

define('INCLUDE_CHECK',1);
require "connect.php";

if(!$_POST)
{
	if($_SERVER['HTTP_REFERER'])
	header('Location : '.$_SERVER['HTTP_REFERER']);
	
	exit;
}

?>

<!DOCTYPE html>
<html>
<head>
<title>The GrandSkyLight Hotel_Reservation Details Form</title>
</head>
<body background="bg01.png">

 <?php
				$Date = $_POST['txtDate'];
	            $First_Name=$_POST['txtFirstName'];
	            $Last_Name=$_POST['txtLastName'];
	            $Duration_Hours=$_POST['txtDuration_Hours'];
	            $Hall_No=$_POST['Hall_No'];
	            $Amount=$_POST['txtAmount'];
	            $Payment_Method=$_POST['PaymentMethod'];
				$confirmation = $_POST['confirmation'];
				
				
				//send the email
		/*$to = $email;
		$subject="Reservation notification From The Grandskylight Hotel";
		$from = 'thegrandskylight@gmail.com';
		$body = "$Date: $arival\n".
		"Fname: $First_Name\n".
		"Lname: $Last_Name \n".
		"Hours: $Duration_Hours \n".
		"Hall No: $Hall_No \n".
		"Amount: $Amount \n".
		"Payment method: $Payment_Method \n".
		"Confirmation: $confirmation\n ";	
		
		$headers = "From: $from \r\n";
		$headers .= "Reply-To: $$from \r\n";
		
		mail($to, $subject, $body,$headers);*/
				
				
					
		$ins="INSERT INTO    conference_facility(Date,First_Name,Last_Name,Duration_Hours,Hall_No,Amount,Payment_Method,confirmation) VALUES('$Date','$First_Name','$Last_Name','$Duration_Hours','$Hall_No','$Amount','$Payment_Method','$confirmation')";
						
       					mysql_query($ins);
						
						echo mysql_error();
				
?>
                <h1>Reservation details:</h1>
                <h3>Date :<?php echo $Date ?></h3>
				<h3>First Name: <?php echo $First_Name ?></h3>
				<h3>Last Name: <?php echo $Last_Name ?></h3>
                <h3>Hours:<?php echo $Duration_Hours ?></h3>
				<h3>Hall No: <?php echo $Hall_No ?></h3>
				<h3>Amount: <?php echo $Amount ?></h3>
				<h3>Payment Method: <?php echo $Payment_Method ?></h3>
				<h3>Confirmation: <?php echo $confirmation ?></h3>
                
               Click<a href="savingreservation.php"> here</a> to save reservations
</body>
</html>