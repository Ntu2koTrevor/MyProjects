<?php
	require "connect.php";
	$Date = $_POST['txtDate'];
	$First_Name=$_POST['txtFirstName'];
	$Last_Name=$_POST['txtLastName'];
	$Reg_No=$_POST['Reg_no'];
	$ID_Card_No=$_POST['ID CARD_No'];
	$Duration_Hours=$_POST['txtDuration_Hours'];
	$Hall_No=$_POST['Hall_No'];
	$Amount=$_POST['txtAmount'];
	$Payment_Method=$_POST['PaymentMethod'];
?>
