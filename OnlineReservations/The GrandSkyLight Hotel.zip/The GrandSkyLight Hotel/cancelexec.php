<?php
include('connect.php');
$confirmation=$_POST['confirmation'];

mysql_query("DELETE FROM reservation_details WHERE confirmation='$confirmation'");
mysql_query("DELETE FROM customer_details WHERE confirmation='$confirmation'");
mysql_query("DELETE FROM rooms_info WHERE confirmation='$confirmation'");
mysql_query("DELETE FROM conference_facility WHERE confirmation='$confirmation'");
header("location: cancel.php");
?>
